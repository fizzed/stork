/**
  * Java Service Launcher
  *
*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <time.h>
#include <direct.h>
#include <Rpcdce.h>
#include <Rpc.h>
#include <tlhelp32.h>
#include <sys/stat.h>

#include "service.h"
#define EXPAND_CLASSPATH_WILDCARDS

#include "wildcard.h"

//service name
LPTSTR szappname;
LPTSTR szservicename;
LPTSTR szdisplayname;
LPTSTR szservicedescription;
LPTSTR szconsolehandler;
LPTSTR szdependencies;
LPTSTR szLoadOrderGroup;
LPTSTR szAccount;
LPTSTR szPwd;
LPTSTR szCmdLine;
DWORD dwStartType;

LPTSTR stopClass;
LPTSTR stopMethod;
LPTSTR stopSignature;
LPTSTR path;

LPTSTR szSystemOutAppend;
LPTSTR szSystemErrAppend;

LPTSTR szinteractwithdesktop;
LPTSTR szparam;

// 0.99d - 19.02.2003 Urs Bloechlinger
LPTSTR szStdOutAppend;
LPTSTR szStdErrAppend;

int stopport;
int global_argc;
int startdelay = 0;
LPTSTR  global_jrePath;
LPTSTR  global_wrkdir;
LPTSTR  global_jvmtype;
LPTSTR* global_argv;

// internal variables
SERVICE_STATUS          ssStatus;       // current status of the service
SERVICE_STATUS_HANDLE   sshStatusHandle;
DWORD                   dwErr = 0;
#ifdef _DEBUG
BOOL                    bDebug = TRUE;
#endif
#ifdef NDEBUG
BOOL                    bDebug = FALSE; 
#endif

BOOL                    bCommandLine = FALSE;
BOOL					bService = FALSE;
BOOL					bCommandLineDebug = FALSE;
BOOL					useConsoleHandler =TRUE;
BOOL					bPaused = FALSE;
TCHAR                   szErr[256];

//p0.99
//redirected stdout and stderr
FILE* restdout = NULL;
FILE* restderr = NULL;
LPTSTR stdoutfile = NULL;
LPTSTR stderrfile = NULL;
LPTSTR logfile = NULL;
LPTSTR logtimestamp = "%Y-%m-%d";


int	exceptionErrorCode = 0; 
LPTSTR onExitError = "";
LPTSTR szModulePath = "";
LPTSTR szreportservicestoppedonmainthreadexit = FALSE;
BOOL breportservicestoppedonmainthreadexit = FALSE;

//Support for calling batch files
LPTSTR szconfigbatch;
LPTSTR szconfigbatchhome;


// internal function prototypes
int tokenize( char* s, char delim );
LPTSTR* stringToArray(char* s, char delim );
LPTSTR next_token( char* s, LPTSTR token );
VOID WINAPI service_ctrl(DWORD dwCtrlCode);
void CmdAddServiceParameterRegistry();
VOID WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv);
VOID CmdInstallService( int argc, LPTSTR* argv );
VOID CmdConfigureService( int argc, LPTSTR* argv );
VOID CmdRemoveService();
VOID CmdDebugService(int argc, LPTSTR* argv);
VOID CmdRunService(int argc, LPTSTR* argv);
BOOL WINAPI ControlHandler ( DWORD dwCtrlType );
//BOOL WINAPI ControlHandler2 ( DWORD dwCtrlType );

DWORD GetParentProcessID(DWORD dwProcessID);
VOID ManageConsole(LPSTR consoleType);
LPSTR GetArg(int argc, LPTSTR* argv, LPSTR name, LPSTR _default, BOOL onlyExists);
VOID private_invalid_parameter_handler(const wchar_t * expression, const wchar_t * function, const wchar_t * file, unsigned int line, uintptr_t pReserved);

VOID runBatch(LPSTR szconfigbatch, LPSTR szconfigbatchhome);


//
//  FUNCTION: main
//
//  PURPOSE: entrypoint for service
//
//  PARAMETERS:
//    argc - number of command line arguments
//    argv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    main() either performs the command line task, or
//    call StartServiceCtrlDispatcher to register the
//    main service thread.  When the this call returns,
//    the service has stopped, so exit.
//
#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup")
void main(int argc, LPTSTR* argv)
{	
	TCHAR env_var_debug[32];
    SERVICE_TABLE_ENTRY dispatchTable[] =
    {
        { TEXT(SZSERVICENAME), (LPSERVICE_MAIN_FUNCTION)service_main },
        { NULL, NULL }
    };

	//Backup parameters to executable, they become overwritten with the java args
	LPTSTR* _argv = argv;
	int _argc = argc;
    returnCode = RET_DEFAULT;
	//Needed for logging - cannot logtofile before here
	InitializeCriticalSection( &csLog );

	if (GetEnvironmentVariable("_JAVA_LAUNCHER_DEBUG", env_var_debug, 32) != 0) {
		bDebug = TRUE;
		printf("----_JAVA_LAUNCHER_DEBUG----\n");
	}

	if (bDebug) logToFile("Entering Main");

    if ( (argc > 1) &&
         ((*argv[1] == '-') ) )
    {
        if ( _stricmp( "install", argv[1]+1 ) == 0 )
        {
			ManageConsole(GetArg(argc, argv, "console", "parent", FALSE));
			getParams( &argc, &argv, FALSE, TRUE );
			dispatchTable[0].lpServiceName = szservicename;					
			CmdInstallService( _argc, _argv );
        }
		else if ( _stricmp( "configure", argv[1]+1 ) == 0 )
        {
			ManageConsole(GetArg(argc, argv, "console", "parent", FALSE));
			getParams( &argc, &argv, FALSE, TRUE );
			dispatchTable[0].lpServiceName = szservicename;
			CmdConfigureService( _argc, _argv );
        }
        else if ( _stricmp( "remove", argv[1]+1 ) == 0 )
        {
			ManageConsole(GetArg(argc, argv, "console", "parent", FALSE));
			getParams( &argc, &argv, FALSE, TRUE );
			dispatchTable[0].lpServiceName = szservicename;
			CmdRemoveService();
        }
        else if ( _stricmp( "debug", argv[1]+1 ) == 0 )
        {
			ManageConsole(GetArg(argc, argv, "console", "parent", FALSE));
            bDebug = TRUE;
			getParams( &argc, &argv, TRUE, TRUE );
			dispatchTable[0].lpServiceName = szservicename;
			bCommandLine = TRUE;
			bCommandLineDebug = TRUE;
			CmdDebugService(argc, argv);
        }
		else if ( _stricmp( "run", argv[1]+1 ) == 0 )
        {
			ManageConsole(GetArg(argc, argv, "console", "parent", FALSE));
			//16.05.01 Erwin Vervondel
			//Allow to run as a standalone application
			getParams( &argc, &argv, FALSE, FALSE );
			dispatchTable[0].lpServiceName = szservicename;
			bCommandLine = TRUE;
			if ( bDebug )
				logToFile( "Calling CmdRunService" );
			CmdRunService(argc, argv);
		}
		else if (_stricmp("runapp", argv[1] + 1) == 0)
		{	
			ManageConsole("hide");
			getParams(&argc, &argv, FALSE, FALSE);
			dispatchTable[0].lpServiceName = szservicename;
			bCommandLine = TRUE;
			if (bDebug)
				logToFile("Calling CmdRunService");
			CmdRunService(argc, argv);
		}
        else
        {
            goto dispatch;
        }
		exit( returnCode );
    }

    // if it doesn't match any of the above parameters
    // the service control manager may be starting the service
    // so we must call StartServiceCtrlDispatcher
    dispatch:
						      
		if (bDebug) logToFile("Entering Dispatch");

		ManageConsole("parent");
		printf( "JSL Java Service Launcher by Michael Roeschter (Michael@Roeschter.com)\nVersion 0.99x December 2021\n" );
		printf( "Command line options:\n" );
		printf( "%s -install [ini] [...]    to install the service\n", argv[0] );
		printf( "%s -configure [ini] [...]  to reconfigure an installed service with new dependencies\n", argv[0] );
		printf( "%s -remove [ini] [...]     to remove the service\n", argv[0] );
		printf( "%s -debug [ini] [...]      to run as a standalone console app for debugging\n", argv[0] );
		printf( "%s -run [ini] [...]        to run as a standalone console app\n", argv[0] );
		printf( "%s -runapp [ini] [...]     to run as a standalone console app with no console output\n", argv[0]);
		printf( "%s -ini ini                to use the specified init file for running as a service (this option is not useful on command line; only use it if you configure the service option in the registry)\n", argv[0] );
		printf("Optional parameters: [...] -console hide | parent | new    'hide' will not show any output on console; 'attach' will show output in current console; 'new' will open a new console window\n");
		printf( "The configurations file used in the -install and -configure commands will be used for running the service.\n" );
		
		//Read parameters from the ini file for this service	
		getParams( &argc, &argv, TRUE, TRUE);

		global_argc = argc;
		global_argv = argv;

		if ( bDebug )
			logToFile( "params read, calling dispatcher" );		

        printf( "\nStartServiceCtrlDispatcher being called.\n" );
        printf( "This may take several seconds.  Please wait.\n" );
		
		bService = TRUE;
		dispatchTable[0].lpServiceName = szservicename;	

        if (!StartServiceCtrlDispatcher(dispatchTable))
		{
            AddToMessageLog(TEXT("StartServiceCtrlDispatcher failed."));
			if ( bDebug )
			{
				logToFile( GetLastErrorText(szErr, 256) );
				logToFile( "StartServiceCtrlDispatcher failed" );
			}
		}

		if ( bDebug )
			logToFile( "StartServiceCtrlDispatcher returned" );
		
		exit( returnCode );
}

void private_invalid_parameter_handler(
	const wchar_t * expression,
	const wchar_t * function,
	const wchar_t * file,
	unsigned int line,
	uintptr_t pReserved
)
{
	AddToMessageLog(TEXT("CRT Error - string buffer overflow."));
	AddToMessageLog(TEXT("Probably reason is stringbuffer exhaustion. Please increase 'stringbuffer' parameter in configuration file."));
	logToFile("CRT Error - string buffer overflow.");
	logToFile("Probably reason is stringbuffer exhaustion. Please increase 'stringbuffer' parameter in configuration file.");
	
	exit(-1);
}

LPSTR GetArg(int argc, LPTSTR* argv, LPSTR name, LPSTR _default, BOOL onlyExists)
{
	for (int i = 1; i < argc; i++)
	{
		if ( argv[i][0] == '-')
		{
			//Is it the name we are looking for?
			if (strcmp(name, argv[i]+1) == 0)
			{
				if (onlyExists == TRUE)
					return name;

				if (i + 1 < argc)
				{
					return argv[i + 1];
				}
			}
		} else {
			//No '-' means it may be the ini file
			if (strcmp(name, "ini") == 0 && i==2)
				return argv[i];
		}
	}
	return _default;
}

void ManageConsole(LPSTR consoleType)
{
	DWORD parentPID = 0;
	FILE* fp;

	if (strcmp(consoleType, "hide") == 0)
		return;

	if (strcmp(consoleType, "parent") == 0)
	{
		parentPID = GetParentProcessID(0);

		if (parentPID != -1 )
		{ 
			if (bDebug) {
				logToFile("Parent Window present");
			}

			BOOL bOk = AttachConsole(parentPID);
			if (!bOk) {
				char buffer[256] = "";
				sprintf_s(buffer, 256, "AttachConsole failed with error %d", GetLastError());
				if (bDebug)
					logToFile(buffer);
			}
			else {
				if (bDebug)
					logToFile("AttachConsole Succesful");
				freopen_s(&fp, "CONOUT$", "w", stdout);
				freopen_s(&fp, "CONOUT$", "w", stderr);
			}
		}
	}

	if (strcmp(consoleType, "new") == 0)
	{
		//printf("%s\n", "AllocConsole");
		AllocConsole();
		freopen_s(&fp, "CONOUT$", "w", stdout);
		freopen_s(&fp, "CONOUT$", "w", stderr);
		//dup2(fileno(stderr), fileno(stdout));
	}
}

DWORD GetParentProcessID(DWORD dwProcessID)
{
	DWORD dwParentProcessID = -1;
	HANDLE			hProcessSnapshot;
	PROCESSENTRY32	processEntry32;

	if ( dwProcessID <= 1 )
		dwProcessID = GetCurrentProcessId();

	hProcessSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnapshot != INVALID_HANDLE_VALUE)
	{
		processEntry32.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hProcessSnapshot, &processEntry32))
		{
			do
			{
				if (dwProcessID == processEntry32.th32ProcessID)
				{
					dwParentProcessID = processEntry32.th32ParentProcessID;
					break;
				}
			} while (Process32Next(hProcessSnapshot, &processEntry32));

			CloseHandle(hProcessSnapshot);
		}
	}

	return dwParentProcessID;
}

// 0.99d - 19.02.2003 Urs Bloechlinger
// Converts kernel time to the string-format given in psTime (i.e. "%Y.%m.%d_%H:%M:%S").
void dateTimeToString (char* psTime, char* TimeFormat)
{
	size_t iMaxSize = 64;
	time_t tTime;
	struct tm pTimeStruct;

	time(&tTime);
	localtime_s(&pTimeStruct, &tTime);
	strftime (psTime, iMaxSize, TimeFormat , &pTimeStruct);
}

BOOL boolVal( char* str)
{
	if ( strcmp( str, "FALSE" ) == 0 )
		return FALSE;
	if ( strcmp( str, "False" ) == 0 )
		return FALSE;
	if ( strcmp( str, "false" ) == 0 )
		return FALSE;
	if ( strcmp( str, "NO" ) == 0 )
		return FALSE;
	if ( strcmp( str, "No" ) == 0 )
		return FALSE;
	if ( strcmp( str, "no" ) == 0 )
		return FALSE;

	if ( strcmp( str, "TRUE" ) == 0 )
		return TRUE;
	if ( strcmp( str, "True" ) == 0 )
		return TRUE;
	if ( strcmp( str, "true" ) == 0 )
		return TRUE;
	if ( strcmp( str, "YES" ) == 0 )
		return TRUE;
	if ( strcmp( str, "Yes" ) == 0 )
		return TRUE;
	if ( strcmp( str, "yes" ) == 0 )
		return TRUE;

	return FALSE;
}

/**
  * Read parameters from the configuration file 
*/
void getParams(int *pargc, LPTSTR** pargv, boolean show, boolean runAsService)
{
	int argc = *pargc;
	LPTSTR* argv = *pargv;
	int nargc;
	LPTSTR* nargv;
	int i;
	size_t i_p;

	//FILE* iniFile;

	LPTSTR _java = "java";
	LPTSTR _service = "service";
	LPTSTR _defines = "defines";

	int params;
	LPTSTR _param = malloc(8);

	size_t bsize = 16000;
	LPTSTR buffer;
	LPTSTR commandLine;
	LPTSTR commandLineStart;
	LPTSTR export;

	size_t pos = 0;
	size_t cpos = 0;
	size_t size = 0;
	int currentParam = 0;
	int startParam = 0;
	char* stmp;
	char* pathformat;
	char* cmdpathformat;
	char* cmdarg;
	//char* nameformat;
	int isclasspath = 0;

	//Number of static parameters of type 
	//Add 1 here if you add new -D style parameters
	int STATIC_PARAMS = 5;

	//Result of changed wrkdir
	int  changedWrkDir = 0;

	TCHAR cszPath[_MAX_PATH];
	LPSTR szPath = cszPath;
	BOOL  explicitIni = FALSE;

	TCHAR szDrive[_MAX_DIR];
	TCHAR szDir[_MAX_DIR];
	TCHAR szFname[_MAX_FNAME];
	TCHAR szExt[_MAX_EXT];

	TCHAR szmName[_MAX_PATH];
	TCHAR szmDrive[_MAX_DIR];
	TCHAR szmDir[_MAX_DIR];
	TCHAR szmFname[_MAX_FNAME];
	TCHAR smzExt[_MAX_EXT];

	strcpy_s(_param, 8, "param00");

	GetModuleFileName(NULL, szmName, _MAX_PATH);
	if (GetModuleFileName(NULL, szmName, _MAX_FNAME) == 0)
	{
		AddToMessageLog(TEXT("Could not get module name, so in consequence could not locate ini file."));
		exit(1);
	}
	_splitpath_s(szmName, szmDrive, _MAX_DIR, szmDir, _MAX_DIR, szmFname, _MAX_FNAME, smzExt, _MAX_EXT);
	if (bDebug)
		printf("Module name decomposed %s %s %s %s\n", szmDrive, szmDir, szmFname, smzExt);

	//Specify the location of the ini file
	LPSTR iniFileName = GetArg(argc, argv, "ini", NULL, FALSE);

	//Resolve explicitely named ini file
 	if (iniFileName != NULL)
	{
		if (bDebug)
			printf("Explicitly named ini file\n");

		strcpy_s(szPath, _MAX_PATH, iniFileName);
		explicitIni = TRUE;

		_splitpath_s(szPath, szDrive, _MAX_DIR, szDir, _MAX_DIR, szFname, _MAX_FNAME, szExt, _MAX_EXT);
		if (bDebug)
			printf("Ini file decomposed %s:%s:%s:%s\n", szDrive, szDir, szFname, szExt);
		//Splitpath can't handle UNC names. So lets rectify that.  drive="" and dir="\\server\dir" needs to become drive="\\server" and dir="\dir" 
		if (szDir != NULL && szDir[0] == '\\' && szDir[1] == '\\')
		{
			i = 2;
			while (szDir[i] != 0 && szDir[i] != '\\')
			{
				i++;
			}
			strcpy_s(szDrive, _MAX_DIR, szDir);
			strcpy_s(szDir, _MAX_DIR, szDrive + i);
			szDrive[i] = 0;
			//strcpy_s( szDrive, _MAX_DIR, szDrive+i );		
		}
		if (bDebug)
			printf("Ini file decomposed after UNC pazj check %s:%s:%s:%s\n", szDrive, szDir, szFname, szExt);

		//Check if relative path, in this case merge to module path. Otherwise just continue and reassemble
		if (szDrive == NULL || strlen(szDrive) == 0)
		{
			//If no drive in path assume drive from executable
			strcpy_s(szDrive, _MAX_DIR, szmDrive);
			if (szDir == NULL || strlen(szDir) == 0)
				//If no directory in path assume directory from executable
				strcpy_s(szDir, _MAX_DIR, szmDir);
			else {
				if (szDir[0] == '.')
				{
					//If ini directory starts with a . then drop first two characters and append to executable directory
					strcat_s(szmDir, _MAX_DIR, szDir + 2);
					strcpy_s(szDir, _MAX_DIR, szmDir);
				}
				else {
					//Otherwise just append to executable directory
					strcat_s(szmDir, _MAX_DIR, szDir);
					strcpy_s(szDir, _MAX_DIR, szmDir);
				}
			}
		}
		if (bDebug)
			printf("Ini file new %s %s %s %s\n", szDrive, szDir, szFname, szExt);
		_snprintf_s(szPath, _MAX_PATH, _MAX_PATH, "%s%s%s%s", szDrive, szDir, szFname, szExt);
		//_makepath_s( szPath, _MAX_PATH, szDrive, szDir, szFname, szExt  );	
		if (bDebug)
			printf("Ini file path final %s\n", szPath);
	}
	else
	{
		//Build ini file
		_snprintf_s(szPath, _MAX_PATH, _MAX_PATH, "%s%s%s%s", szmDrive, szmDir, szmFname, ".ini");
		//_makepath_s(  szPath, _MAX_PATH, szmDrive, szmDir, szmFname, ".ini" );
		if (bDebug)
			printf("Ini file path final %s\n", szPath);
		_splitpath_s(szPath, szDrive, _MAX_DIR, szDir, _MAX_DIR, szFname, _MAX_FNAME, szExt, _MAX_EXT);
		if (bDebug)
			printf("Final ini file decomposed %s %s %s %s\n", szDrive, szDir, szFname, szExt);
	}
	//Validate the .ini file
	struct stat stats;
	//if( ( fopen_s( &iniFile, szPath, "r" )) != 0 )
	if (stat(szPath, &stats) != 0)
	{
		printf("Initialization file '%s' not found\n", szPath);
		returnCode = RET_ERROR;
		exit(returnCode);
	}
	//fclose( iniFile );

	if (show)
		printf("\nInitalization file: %s\n", szPath);

#pragma warning(disable:4267)
	bsize = GetPrivateProfileInt(_service, "stringbuffer", bsize, szPath);
#pragma warning(default:4267)

	buffer = malloc(bsize);
	commandLine = malloc(bsize);
	commandLineStart = commandLine;

	if (show)
		printf("%s=%zi\n", "stringbuffer", bsize);


	//Export definitions

	//Export variables
	size = 1 + JSLGetProfileString(_defines, "export", NULL, buffer, bsize - pos, szPath);
	export = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "export", export);

	//Tokenize export variable list
	exportParams = stringToArray(export, ',');
	for (i = 0; exportParams[i] != NULL; i++)
	{
		size = 1 + JSLGetProfileString(_defines, exportParams[i], NULL, buffer, bsize - pos, szPath);
		SetEnvironmentVariable(exportParams[i], buffer);
		pos += size;
		if (show)
			printf("export %s=%s\n", exportParams[i], buffer);

		buffer += size;
	}

	//Now we start logging and redirect output

	//stdout and stderr redirect
	size = 1 + JSLGetProfileString(_service, "stdout", "", buffer, bsize - pos, szPath);
	stdoutfile = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "stdout", stdoutfile);

	size = 1 + JSLGetProfileString(_service, "stderr", "", buffer, bsize - pos, szPath);
	stderrfile = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "stderr", stderrfile);

	// 0.99d - 19.02.2003 Urs Bloechlinger
	// overwrite or append
	size = 1 + JSLGetProfileString(_service, "stdoutappend", "no", buffer, bsize - pos, szPath);
	szStdOutAppend = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "stdoutappend", szStdOutAppend);

	stdOutAppend = boolVal(szStdOutAppend);

	size = 1 + JSLGetProfileString(_service, "stderrappend", "no", buffer, bsize - pos, szPath);
	szStdErrAppend = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "stderrappend", szStdErrAppend);

	stdErrAppend = boolVal(szStdErrAppend);
	// end 0.99d

	//logfile and logtimestamp
	size = 1 + JSLGetProfileString(_service, "logtimestamp", "%%Y-%%m-%%d", buffer, bsize - pos, szPath);
	logtimestamp = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "logtimestamp", logtimestamp);

	//logfile and logtimestamp
	size = 1 + JSLGetProfileString(_service, "logfile", "", buffer, bsize - pos, szPath);
	logfile = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "logfile", logfile);
	
	//Working directory
	size = 1 + JSLGetProfileString(_java, "wrkdir", "", buffer, bsize - pos, szPath);
	if (buffer[0] != 0)
		// 30.12.2008: Begin GCollin
		// Support for '.' in working dir, replaced with .ini directory
	{
		if (buffer[0] == '.')
		{
			size = size - 1 + strlen(szDrive) + strlen(szDir);
			global_wrkdir = malloc(size);
			strcpy_s(global_wrkdir, size, szDrive);
			strcat_s(global_wrkdir, size, szDir);
			if (buffer[1] == '\\')
				strcat_s(global_wrkdir, size, buffer + 2);
			if (bsize - pos >= size)
				strcpy_s(buffer, bsize - pos, global_wrkdir);
			if (global_wrkdir)
				free(global_wrkdir);
		}
		global_wrkdir = buffer;
		// 30.12.2008: End GCollin 
	}
	else
		global_wrkdir = 0;

	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "wrkdir", global_wrkdir);

	//try to change work directory
	if (NULL != global_wrkdir) {
		changedWrkDir = _chdir(global_wrkdir);
			
		if (bDebug)
			logToFile("Changed working directory to:");
		if (bDebug)
			logToFile(global_wrkdir);

		if (bDebug && changedWrkDir != 0)
		{
		
			logToFile("Failed changing working directory");
			AddToMessageLog(TEXT("Unable to change working directory."));
		}
	}

	//Try logging - fail if file can't be opened
	if (bDebug)
		logFileExists();

	/*Warning that we are redirecting*/
	if (bDebug) {
		logToFile("Now logging to file:");
		logToFile(logfile);
	}

	//Now try to redirect stdout if defined
	redirect_stdxxx();

	

	//Now we can install and error handler
	//CRT error handling:
	_set_invalid_parameter_handler(&private_invalid_parameter_handler);

	if ( bDebug )
		logToFile( "Start loading parameters" );


	//Load the initialization parameters
	//First we give the batch file a chance to run if configured

	size = 1 + JSLGetProfileString(_service, "configbatch", "", buffer, bsize - pos, szPath);
	szconfigbatch = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "configbatch", szconfigbatch);

	size = 1 + JSLGetProfileString(_service, "configbatchhome", "", buffer, bsize - pos, szPath);
	szconfigbatchhome = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "configbatchhome", szconfigbatchhome);

	//Both variables need to be configured
	if (strlen(szconfigbatch) != 0 && strlen(szconfigbatchhome) != 0)
	{
		if (bDebug)
			printf("Running batch file '%s' with home '%s'", szconfigbatch, szconfigbatchhome);
		runBatch(szconfigbatch, szconfigbatchhome);
	}
	else {
		if (bDebug)
			printf("Skipping batch file as either configbatch:'%s' or configbatchhome:'%s' are not set\n", szconfigbatch, szconfigbatchhome);
	}

	//Load remaining initialization parameters

	//Failure actions
	failureActions.dwResetPeriod = GetPrivateProfileInt( _service, "failureactions_resetperiod", 0, szPath );
	if ( show )
	  printf( "%s=%li\n", "failureactions_resetperiod", failureActions.dwResetPeriod );

	size = 1 + JSLGetProfileString( _service, "failureactions_rebootmsg", "", buffer, bsize-pos, szPath );	
	failureActions.lpRebootMsg = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "failureactions_rebootmsg", failureActions.lpRebootMsg );

	size = 1 + JSLGetProfileString( _service, "failureactions_command", "", buffer, bsize-pos, szPath );	
	failureActions.lpCommand = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "failureactions_command", failureActions.lpCommand );

	failureActions.cActions = GetPrivateProfileInt( _service, "failureactions_actions", 0, szPath );
	if ( show )
	  printf( "%s=%li\n", "failureactions_actions", failureActions.cActions );

	//Read list of failure actions
	failureActions.lpsaActions = NULL;
	if ( failureActions.cActions > 0 )
	{	
		fAction = malloc( sizeof(SC_ACTION)*failureActions.cActions);
		failureActions.lpsaActions = fAction;
		#pragma warning(disable:4018)
		for( i=0; i<failureActions.cActions; i++)
		#pragma warning(default:4018)
		{
			char name[16]; 
			sprintf_s(name, 16, "action%d_type", i);
			fAction[i].Type = GetPrivateProfileInt( _service, name, -1, szPath );
			//Detect and war about wrong non existant parameter
			if (fAction[i].Type == -1)
			{
				printf( "ERROR: Parameter %s not found\n", name );
				exit(1);
			}
			if ( show )
			  printf( "%s=%li\n", name, fAction[i].Type );
			
			sprintf_s(name, 16, "action%d_delay", i);
			fAction[i].Delay = GetPrivateProfileInt( _service, name, 0, szPath );
			if ( show )
			  printf( "%s=%li\n", name, fAction[i].Delay );
		}
	}

	//End failure actions

	//Java command line parsing
	size = 1 + JSLGetProfileString( _java, "cmdline", "", buffer, bsize-pos, szPath );	
	szCmdLine = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "cmdline", szCmdLine );

	params = tokenize( szCmdLine, ' ' );
	cmdarg = NULL;	
	if ( params == 0 )
		szCmdLine = NULL;

	//param count
	if ( szCmdLine == NULL )
		params = GetPrivateProfileInt( _java, "params", 0, szPath );

	if (runAsService)
	{
	  nargc = params + STATIC_PARAMS;// Changed 24.06.1999, Heiner Jostkleigrewe
	}
	else
	{
	  nargc = params + 1 + 1; // Changed 16.05.2001, Erwin Vervondel //added +1 for -Dinifile parameter
	}
	nargv = malloc(( nargc ) * sizeof(LPTSTR));// Changed 24.06.1999, Heiner Jostkleigrewe

	*pargc = nargc;
    *pargv = nargv;
	nargv[currentParam++] = argv[0];

	//01.03.2001 Erwin Vervondel
	//Allow definition of jrepath in ini file
	size = 1 + JSLGetProfileString( _java, "jrepath", "", buffer, bsize-pos, szPath );	
	global_jrePath = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "jrepath", global_jrePath);

	//Jvmtype
	//The default runs through the list of known locations
	size = 1 + JSLGetProfileString( _java, "jvmtype", "server,client,hotspot,classic,jrockit" , buffer, bsize-pos, szPath );	
	global_jvmtype = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "jvmtype", global_jvmtype);	

	//Locations to search for the JRE
	size = 1 + JSLGetProfileString(_java, "jvmsearch", "path,local,registry", buffer, bsize - pos, szPath);
	jreSearchP = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "jvmsearch", jreSearchP);

	jreSearch = stringToArray(jreSearchP, ',');

	jreSearchPath = FALSE;
	jreSearchLocal = FALSE;
	jreSearchRegistry = FALSE;
	for (i = 0; jreSearch[i] != NULL; i++)
	{
		if (strcmp(jreSearch[i], "path") == 0) jreSearchPath = TRUE;
		if (strcmp(jreSearch[i], "local") == 0) jreSearchLocal = TRUE;
		if (strcmp(jreSearch[i], "registry") == 0) jreSearchRegistry = TRUE;
	}
	if (show)
	{
		printf("%s=%d\n", "jreSearchPath", jreSearchPath);
		printf("%s=%d\n", "jreSearchLocal", jreSearchLocal);
		printf("%s=%d\n", "jreSearchRegistry", jreSearchRegistry);
	}

	//Allowed JVM versions
	size = 1 + JSLGetProfileString(_java, "jvmversionallowed", "ANY", buffer, bsize - pos, szPath);
	jvmversionallowed = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "jvmversionallowed", jvmversionallowed);

	jreVersions = stringToArray(jvmversionallowed, ',');


	//Custom registry paths
	size = 1 + JSLGetProfileString(_java, "customregistrypaths", "", buffer, bsize - pos, szPath);
	customregistrypaths = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "customregistrypaths", customregistrypaths);

	customregistry = stringToArray(customregistrypaths, ',');

	//registryfindjre
	size = 1 + JSLGetProfileString(_java, "registryfindjre", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindjre", szparam);

	registryfindjre = boolVal(szparam);

	//registryfindjdk
	size = 1 + JSLGetProfileString(_java, "registryfindjdk", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindjdk", szparam);

	registryfindjdk = boolVal(szparam);

	//registryfindcorretto
	size = 1 + JSLGetProfileString(_java, "registryfindcorretto", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindcorretto", szparam);

	registryfindcorretto = boolVal(szparam);

	//registryfindadoptopenjdk
	size = 1 + JSLGetProfileString(_java, "registryfindadoptopenjdk", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindadoptopenjdk", szparam);

	registryfindadoptopenjdk = boolVal(szparam);

	//registryfindj9
	size = 1 + JSLGetProfileString(_java, "registryfindj9", "no", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindj9", szparam);

	registryfindj9 = boolVal(szparam);

	//registryfindazul
	size = 1 + JSLGetProfileString(_java, "registryfindazul", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindazul", szparam);

	registryfindazul = boolVal(szparam);

	//registryfindoracle
	size = 1 + JSLGetProfileString(_java, "registryfindoracle", "yes", buffer, bsize - pos, szPath);
	szparam = buffer;
	buffer += size;
	pos += size;
	if (show)
		printf("%s=%s\n", "registryfindoracle", szparam);

	registryfindoracle = boolVal(szparam);

	// Create dependencies buffer (a double null terminated array)
	szdependencies = malloc( 1024 );
	memset(szdependencies, 0, 1024);
	size = JSLGetProfileString( _service, "dependencies", "", szdependencies, 1023, szPath );	

	if ( show )
		printf( "%s=%s\n", "dependencies", szdependencies );
	
	for (i_p = 0; i_p < size; i_p++)
	{
		if (szdependencies[i_p] == ',') 
			szdependencies[i_p] = 0;

		
	}
	szdependencies[ size ] = 0;

	if ( show ) {
		size_t deppos = 0;
		for (i_p = 0; i_p < size+1; i_p++)
		{
			if (szdependencies[i_p] == 0) 
			{
				printf( "%s=%s\n", "dependency", szdependencies + deppos  );
				deppos = i_p+1;
			}
		}
	}
	//end 01.03.2001 Erwin Vervondel


	dwStartType = SERVICE_AUTO_START;
	//start type
	size = 1 + JSLGetProfileString( _service, "starttype", "auto", buffer, bsize-pos, szPath );
	if ( show )
	  printf( "%s=%s\n", "starttype", buffer);	

	if (strcmp(buffer, "boot") == 0 )
		dwStartType = SERVICE_BOOT_START;

	if (strcmp(buffer, "system") == 0 )
		dwStartType = SERVICE_SYSTEM_START;

	if (strcmp(buffer, "auto") == 0 )
		dwStartType = SERVICE_AUTO_START;

	if (strcmp(buffer, "demand") == 0 )
		dwStartType = SERVICE_DEMAND_START;

	if (strcmp(buffer, "disabled") == 0 )
		dwStartType = SERVICE_DISABLED;

	buffer += size;
	pos += size;
	

	szAccount = NULL;
	//Start account
	size = 1 + JSLGetProfileString( _service, "account", "", buffer, bsize-pos, szPath );
	if ( buffer[0] != 0 )
		szAccount = buffer;
    else
        szAccount = 0;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "account", szAccount);	


	szPwd = NULL;
	//Start password
	size = 1 + JSLGetProfileString( _service, "password", "", buffer, bsize-pos, szPath );
	if ( buffer[0] != 0 )
		szPwd = buffer;
    else
        szPwd = 0;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "password", szPwd);	

	szLoadOrderGroup = NULL;
	//Load order group
	size = 1 + JSLGetProfileString( _service, "loadordergroup", "", buffer, bsize-pos, szPath );	
	if ( buffer[0] != 0 )
		szLoadOrderGroup = buffer;
    else
        szLoadOrderGroup = 0;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "loadordergroup", szLoadOrderGroup);

	//Application name
	size = 1 + JSLGetProfileString( _service, "appname", "appname", buffer, bsize-pos, szPath );	
	szappname = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "appname", szappname );

	//Service name
	size = 1 + JSLGetProfileString( _service, "servicename", "servicename", buffer, bsize-pos, szPath );	
	szservicename = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "servicename", szservicename );

	//Displayname
	size = 1 + JSLGetProfileString( _service, "displayname", "displayname", buffer, bsize-pos, szPath );	
	szdisplayname = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "displayname", szdisplayname );

	//Description
	size = 1 + JSLGetProfileString( _service, "servicedescription", szdisplayname, buffer, bsize-pos, szPath );	
	szservicedescription = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "servicedescription", szservicedescription );

	//System.out and System.err redirect
	size = 1 + JSLGetProfileString( _service, "systemout", "", buffer, bsize-pos, szPath );	
	systemOut = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "systemout", systemOut );

	size = 1 + JSLGetProfileString( _service, "systemerr", "", buffer, bsize-pos, szPath );	
	systemErr = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "systemerr", systemErr );

	size = 1 + JSLGetProfileString( _service, "systemoutappend", "no", buffer, bsize-pos, szPath );	
	szSystemOutAppend = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "systemoutappend", szSystemOutAppend );

	systemOutAppend = boolVal( szSystemOutAppend );

	size = 1 + JSLGetProfileString( _service, "systemerrappend", "no", buffer, bsize-pos, szPath );	
	szSystemErrAppend = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "systemerrappend", szSystemErrAppend );

	systemErrAppend = boolVal( szSystemErrAppend );

	
	//interact with desktop
	size = 1 + JSLGetProfileString( _service, "interactwithdesktop", "no", buffer, bsize-pos, szPath );	
	szinteractwithdesktop = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "interactwithdesktop", szinteractwithdesktop );

	interactwithdesktop = boolVal( szinteractwithdesktop );

	//Exception error code
	exceptionErrorCode = GetPrivateProfileInt( _service, "exceptionerrorcode", exceptionErrorCode,  szPath );	
 
	if ( show )
	  printf( "%s=%li\n", "exceptionerrorcode", exceptionErrorCode );

	//Behaviour for non zero exit code
	size = 1 + JSLGetProfileString( _service, "onexiterror", "ignore", buffer, bsize-pos, szPath );	
	onExitError = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "onexiterror", onExitError );

	//Behaviour on main thread exit
	size = 1 + JSLGetProfileString( _service, "reportservicestoppedonmainthreadexit", "no", buffer, bsize-pos, szPath );	
	szreportservicestoppedonmainthreadexit = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "reportservicestoppedonmainthreadexit", szreportservicestoppedonmainthreadexit );

	breportservicestoppedonmainthreadexit = boolVal( szreportservicestoppedonmainthreadexit );

	//Class to use for stopping the service
	size = 1 + JSLGetProfileString( _service, "stopclass", "", buffer, bsize-pos, szPath );	
	stopClass = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "stopclass", stopClass );

	//Method to use for stopping the service
	size = 1 + JSLGetProfileString( _service, "stopmethod", "", buffer, bsize-pos, szPath );	
	stopMethod = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "stopmethod", stopMethod );

	//Signature to use for stopping the service
	size = 1 + JSLGetProfileString( _service, "stopsignature", "", buffer, bsize-pos, szPath );	
	stopSignature = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "stopsignature", stopSignature );

	//Parameters passed when stopping the service
	size = 1 + JSLGetProfileString( _service, "stopparams", "", buffer, bsize-pos, szPath );	
	stmp = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "stopparams", stmp );

	stopParams = stringToArray( stmp, ' ' );

	//Class to use for pausing the service
	size = 1 + JSLGetProfileString( _service, "pauseclass", "", buffer, bsize-pos, szPath );	
	pauseClass = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "pauseclass", pauseClass );

	//Method to use for pausing the service
	size = 1 + JSLGetProfileString( _service, "pausemethod", "", buffer, bsize-pos, szPath );	
	pauseMethod = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "pausemethod", pauseMethod );

	//Signature to use for pausing the service
	size = 1 + JSLGetProfileString( _service, "pausesignature", "", buffer, bsize-pos, szPath );	
	pauseSignature = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "pausesignature", pauseSignature );

	//Parameters passed when pausing the service
	size = 1 + JSLGetProfileString( _service, "pauseparams", "", buffer, bsize-pos, szPath );	
	stmp = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "pauseparams", stmp );

	pauseParams = stringToArray( stmp,' ' );



	//Class to use for continueing the service
	size = 1 + JSLGetProfileString( _service, "contclass", "", buffer, bsize-pos, szPath );	
	contClass = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "contclass", contClass );

	//Method to use for continueing the service
	size = 1 + JSLGetProfileString( _service, "contmethod", "", buffer, bsize-pos, szPath );	
	contMethod = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "contmethod", contMethod );

	//Signature to use for continueing the service
	size = 1 + JSLGetProfileString( _service, "contsignature", "", buffer, bsize-pos, szPath );	
	contSignature = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "contsignature", contSignature );

	//Parameters passed when the service is continued
	size = 1 + JSLGetProfileString( _service, "contparams", "", buffer, bsize-pos, szPath );	
	stmp = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "contparams", stmp );

	contParams = stringToArray( stmp,' ' );


	//Class to use for confirming service running
	size = 1 + JSLGetProfileString( _service, "confirmrunclass", "", buffer, bsize-pos, szPath );	
	confirmrunClass = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "confirmrunclass", confirmrunClass );

	//Method to use for confirming service running
	size = 1 + JSLGetProfileString( _service, "confirmrunmethod", "", buffer, bsize-pos, szPath );	
	confirmrunMethod = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "confirmrunmethod", confirmrunMethod );

	//Signature to use for confirming service running
	size = 1 + JSLGetProfileString( _service, "confirmrunsignature", "", buffer, bsize-pos, szPath );	
	confirmrunSignature = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "confirmrunsignature", confirmrunSignature );

	//Parameters passed when confirming service running
	size = 1 + JSLGetProfileString( _service, "confirmrunparams", "", buffer, bsize-pos, szPath );	
	stmp = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "confirmrunparams", stmp );

	confirmrunParams = stringToArray( stmp,' ' );



	//Class to use for premain call
	size = 1 + JSLGetProfileString( _service, "premainclass", "", buffer, bsize-pos, szPath );	
	premainClass = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "premainclass", premainClass );

	//Method to use for premain call
	size = 1 + JSLGetProfileString( _service, "premainmethod", "", buffer, bsize-pos, szPath );	
	premainMethod = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "premainmethod", premainMethod );

	//Signature to use for premain call
	size = 1 + JSLGetProfileString( _service, "premainsignature", "", buffer, bsize-pos, szPath );	
	premainSignature = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "premainsignature", premainSignature );

	//Parameters passed when premain is called
	size = 1 + JSLGetProfileString( _service, "premainparams", "", buffer, bsize-pos, szPath );	
	stmp = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "premainparams", stmp );

	premainParams = stringToArray( stmp, ' ' );


	//Stop port
	stopport = GetPrivateProfileInt( _service, "stopport", stopport,  szPath );	
 
	if ( show )
	  printf( "%s=%li\n", "stopport", stopport );

	//Stop port
	startdelay = GetPrivateProfileInt( _service, "startdelay", startdelay,  szPath );	
 
	if ( show )
	  printf( "%s=%li\n", "startdelay", startdelay );
	

	//Using a console handler
	size = 1 + JSLGetProfileString( _service, "useconsolehandler", "yes", buffer, bsize-pos, szPath );	
	szconsolehandler = buffer;
	buffer += size;
	pos += size;

	useConsoleHandler = boolVal( szconsolehandler );

	if ( show )
	  printf( "%s=%s\n", "useconsolehandler", szconsolehandler );


	size = 1 + JSLGetProfileString( _service, "path", "", buffer, bsize-pos, szPath );	
	path = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "path", path );

	if ( strlen( path ) != 0 )
		SetEnvironmentVariable( "PATH", path );

	//Executable to run the service from 
	size = 1 + JSLGetProfileString( _service, "modulepath", szModulePath, buffer, bsize-pos, szPath );	
	szModulePath = buffer;
	buffer += size;
	pos += size;
	if ( show )
	  printf( "%s=%s\n", "modulepath", szModulePath );

	if ( bDebug )
		logToFile( "Loaded module path" );		

	

	//Read first param ...
	if ( szCmdLine == NULL )
	{
		size = 1 + JSLGetProfileString( _java, _param, "", buffer, bsize-pos, szPath );	
		stmp = buffer;		
		buffer += size;
		pos += size;
	} else {
		cmdarg = next_token( szCmdLine, cmdarg );
		stmp = cmdarg;
	}			

	//and check for -classic -hotspot -server -client params
	if (strcmp(stmp, "-classic") == 0 || strcmp(stmp, "-server") == 0 || strcmp(stmp, "-hotspot") == 0 || strcmp(stmp, "-client") == 0 )
	{
	  startParam = 1;
	  _snprintf_s( commandLine, bsize-cpos, bsize-cpos, "%s ", stmp );
	  nargv[currentParam++] = stmp;
	  commandLine += size;
	  cpos += size;	  
	  pos += size;
	  if ( show && szCmdLine == NULL )
		printf( "%s=%s\n", _param, stmp );
	  else
	  {
		printf( "%s\n", stmp );		
	  }
	  printf( "%s", commandLine );
	} else {
		//Start again 
		cmdarg = NULL;
	}
			

	if ( bDebug )
		logToFile( "After JVM type check" );

	//16.05.01 Erwin Vervondel
	//only set 'service' options if application is run as service
	if (runAsService)
	{		
		//16.7.99 Michael R�schter
		//Made string formatting more robust
		#ifdef VC6
		size = 1 + _snprintf( buffer, bsize-pos, "-Dservice.stop.port=%li", stopport );
		#else
		size = 1 + _snprintf_s( buffer, bsize-pos, bsize-pos, "-Dservice.stop.port=%li", stopport );
		#endif
		_snprintf_s( commandLine, bsize-cpos, bsize-cpos, "%s ", buffer );
		commandLine += size;
		cpos += size;
		nargv[currentParam++] = buffer;	
		buffer += size;
		pos += size;	

		printf( "%s", commandLine );

		//New 24.06.1999, Heiner Jostkleigrewe
		//16.7.99 Michael R�schter
		//Made string formatting more robust
			
		pathformat = "-Dservice.path=%s%s";
		cmdpathformat = "-Dservice.path=%s%s ";
		if (  strchr( szDir, ' ' ) )
			cmdpathformat = "\"-Dservice.path=%s%s\" ";		
		
		#ifdef VC6
		size = 1 + _snprintf( buffer, bsize-pos, pathformat, szDrive, szDir );
		#else
		size = 1 + _snprintf_s( buffer, bsize-pos, bsize-pos, pathformat, szDrive, szDir );
		#endif

		nargv[currentParam++] = buffer;
		buffer += size;
		pos += size;
		
		#ifdef VC6
		size = _snprintf( commandLine, bsize-cpos, cmdpathformat, szDrive, szDir );
		#else
		size = _snprintf_s( commandLine, bsize-cpos, bsize-cpos, cmdpathformat, szDrive, szDir );
		#endif
		commandLine += size;
		cpos += size;
		
	
		pathformat = "-Dservice.name=%s";
		cmdpathformat = "-Dservice.name=%s ";
		if ( strchr( szservicename, ' ' )  )
			cmdpathformat = "\"-Dservice.name=%s\" ";
			
		size = 1 + _snprintf_s( buffer, bsize-pos, bsize-pos, pathformat, szservicename );
		nargv[currentParam++] = buffer;
		buffer += size;
		pos += size;

		size = _snprintf_s( commandLine, bsize-cpos, bsize-cpos, cmdpathformat, szservicename );
		commandLine += size;
		cpos += size;
		
	
	}	
	//Add full path to ini file to systems options. This is always usefule.
	//Mainly used for the pre main method hooks
	//Detect spaces in path
	
	if ( bDebug )
		logToFile( "After service parameter parsing" );

	pathformat = "-Dservice.inifile=%s";
	cmdpathformat = "-Dservice.inifile=%s ";
	if (  strchr( szPath, ' ' ) )
		cmdpathformat = "\"-Dservice.inifile=%s\" ";
	
	
	size = 1 + _snprintf_s( buffer, bsize-pos, bsize-pos, pathformat, szPath );
	nargv[currentParam++] = buffer;	
	buffer += size;
	pos += size;
	
	size = _snprintf_s( commandLine, bsize-cpos, bsize-cpos, cmdpathformat, szPath );
	commandLine += size;
	cpos += size;		
	
	if ( bDebug )
		logToFile( "After ini file options" );

	if ( bDebug )
		logToFile( "Java command line handling:" );
/*
	if (show )
	for ( i=0; i<params; i++ )
	{
		cmdarg = next_token( szCmdLine, cmdarg);
		printf( "%s\n", cmdarg );
	}
*/

	for( i=startParam; i<params; i++)
	{
		_param[5] = 48 + i / 10;
		_param[6] = 48 + i % 10;

		if ( szCmdLine == NULL )
		{
			size = 1+JSLGetProfileString( _java, _param, "", buffer, bsize-pos, szPath );	
			nargv[ currentParam++ ] = buffer;
			buffer += size;
			pos += size;
			if ( show )
				printf( "%s=%s\n", _param, nargv[ currentParam - 1  ] );
		} else {
			cmdarg = next_token( szCmdLine, cmdarg);
			nargv[ currentParam++ ] = cmdarg;
			if ( show )
				printf( "%s\n", cmdarg );
		}
				
		if ( isclasspath )
		{
			nargv[currentParam-1] = (char*)JLI_WildcardExpandClasspath(nargv[currentParam-1]); 
			isclasspath = 0;
			if (show) printf("%s=%s\n", "Expanded classpath", nargv[currentParam - 1]);
				
		} else {
			if (strcmp(nargv[currentParam-1],"-cp")==0 || strcmp(nargv[currentParam-1],"-classpath")==0 )
				isclasspath = 1;
		}
				
		//if (show || bDebug) {
			size = 1 + strlen(nargv[currentParam - 1]);
			//commandLine = ensureBufferCapacity(&commandLineStart, &bsize, cpos, size + 1);
			_snprintf_s(commandLine, bsize - cpos, bsize - cpos, "%s ", nargv[currentParam - 1]);

			commandLine += size;
			cpos += size;
		//}

		if ( bDebug )
			logToFile( nargv[ currentParam - 1  ] );
	}	

	if ( show )
		printf( "Java command line:\njava %s\n", commandLineStart );	

	if ( bDebug )
		logToFile( commandLineStart );


	if (bDebug)
	{
		logToFile("Finished parsing parameters");
		logToFile("Parameter Buffer size:");
		logToFileD(bsize);
		logToFile("Parameter buffer used:");
		logToFileD(pos);
	}

	if (pos >= bsize)
	{
		logToFile("Warning stringbuffer exhausted. Please increase 'stringbuffer' in configuration file.");
	}

}

	/*
void safe_snprintf_s()
{
	//
}
*/

void checkHeap()
{	
	if (!HeapValidate(GetProcessHeap(), 0, NULL))
	{
		printf("HEAP corrupt");
		exit(1);
	}
}

//Check capacity of buffer 
//Allocate with oldbuffer size capacity - deallocate old
//Return pointer to current position in new buffer
LPSTR ensureBufferCapacity(char** oldBuffer, size_t* oldBufferSize, size_t currentPosition, size_t size )
{
	LPSTR _oldBuffer = *oldBuffer;
	size_t _oldBufferSize = *oldBufferSize;
	if (currentPosition + size <= _oldBufferSize) return  _oldBuffer + currentPosition;

	size_t newSize = _oldBufferSize + currentPosition + size;

	if (bDebug)
	{
		logToFile("Expanding buffer old/new");
		logToFileD(_oldBufferSize);
		logToFileD(newSize);
	}

	LPSTR newBuffer = malloc(newSize);

	//Copy old content
	strcpy_s(newBuffer, newSize, _oldBuffer);

	//Deallocate old
	free(_oldBuffer);

	//Adjust buffer
	*oldBufferSize = newSize;
	*oldBuffer = newBuffer;
	return newBuffer + currentPosition;
}

LPTSTR* stringToArray(char* s, char delim )
{
	int size;
	LPTSTR* array = NULL;
	int i;
	LPTSTR token = NULL;

	if (s == NULL )
		return array;

	size = tokenize(s, delim );
	
	array = malloc( (size+1) * sizeof(LPTSTR) );
	array[size] = NULL;

	for( i=0; i<size; i++)
	{
		token = next_token(s,token);
		array[i] = token;
	}
	return array;
}


int tokenize( char* s, char delim )
{
	int count = 0;
	int state = 0; //0=looking for next start; 1=looking for end(space or zero); 2=looking for end(quote or zero)
	
	if ( s == NULL )
		return 0;
	
	while ( *s != 0 )
	{
		//Look for next token start
		if ( state == 0 )
		{
			//Whitespaces is nulled
			while( *s == ' ' || *s == '\r' || *s == '\n' )
				*(s++) = 0;

			//quotes are nulled and transfer to state 2
			if ( *s== '\"' )
			{
				*(s++) = 0;
				state = 2;
			} else {
				state = 1;
			}
			if ( *s != 0 )
				count++;
		}
		if ( state == 1 )
		{
			//look for delimiter or zero
			while( *s != delim && *s!= 0)
				s++;

			//Null delimiter and move on
			if ( *s != 0 )
				*(s++) = 0;
			//Do nothing if 0 was found

			//Set state to 0 and move on
			state = 0;
		}
		if ( state == 2 )
		{
			//look for quote or zero
			while( *s != '\"' && *s!= 0)
				s++;
			//Null space and move on
			if ( *s != 0 )
				*(s++) = 0;
			//Do nothing if 0 was found
			state = 0;
		}
	}
		
	return count;
}

LPTSTR next_token( char* s, LPTSTR token )
{
	if ( token != NULL )
		s = token + strlen(token);
		
	while ( *s == 0 )
		s++;
	
	//printf( "token string: '%s'\n", s );
	return s;
}

void getIniFile( LPTSTR szPath )
{
	int i;
    if ( GetModuleFileName( NULL, szPath, 512 ) == 0)
		AddToMessageLog(TEXT("Could not get module name, so in consequence could not locate ini file."));	
	//construct the ini file name 	
	
	for( i=0; szPath[i] != 0; i++ );
	szPath[i-3] = 'i';
	szPath[i-2] = 'n';
	szPath[i-1] = 'i';
}


size_t JSLGetProfileStringR( LPTSTR section, LPTSTR name, LPTSTR _default, LPTSTR buffer, size_t bsize, LPTSTR path, int depth )
{
	size_t size = bsize;
	LPTSTR tmpbuf = NULL;
	LPTSTR start;
	LPTSTR stop;
	LPTSTR buf;
	LPTSTR _defines = "defines";
	size_t tmpsize = 0;
	size_t recursion = 1;
	
	#pragma warning(disable:4267)
	GetPrivateProfileString( section, name, _default, buffer, bsize, path );
	#pragma warning(default:4267)

	if ( bDebug )
		printf( "Ini file: %s = %s\n" , name, buffer );

	buf = buffer;
	start = strchr( buf,'%');

	//printf( "Parsing %s\n", buf );

	//no buffer if there is no substitution
	if ( start  )
	{
		//printf( "found %% \n");
		tmpbuf = malloc( bsize );
		tmpbuf[0] = 0;
	}

	while ( start)
	{
		//printf( "A %s\n", buf );
		//printf( "B %s\n", tmpbuf );

		stop = strchr( start+1, '%' );
		if ( stop )
		{
			//Deliminate variable with zeros (replacing the %)
			start[0] = 0;
			stop[0] = 0;
			
			//printf( "T %s\n", start+1 );
			if ( size >= strlen( buf ) )
			{
				strcat_s( tmpbuf, bsize, buf );
				size -= strlen(buf);
			}
			//Convert %% in to single %
			if ( stop - start == 1 )
			{
				if ( size >= 1 )
				{
					strcat_s( tmpbuf, bsize, "%" );
					size--;
				}
			} else
			{
				//Look for the value in the defines section first
				//Prevent endless recursion				
				//Detects indirect recursion by limiting depth of recursion
				if ( 0 == strcmp( section, _defines ) && depth>=32)  
					recursion = 0;
				//Special case. If a variable in the define section contains a reference to itself, 
				//we take this to mean it is referencing an environment variable with same name
				//e.g.  PATH=%PATH%;c:\temp
				//Obviously the above is useful in many situations
				if ( 0 == strcmp( section, _defines ) && 0 == strcmp( start+1, name ) )  
					recursion = 0;

				//Now check for the variable definition in the variable list ....
				if ( recursion )
					tmpsize = JSLGetProfileStringR( _defines, start+1, "", tmpbuf + strlen(tmpbuf), size, path, depth+1 );
				//.. if not found look for environement variables

				#pragma warning(disable:4267)
				if ( tmpsize == 0 )
				{
					tmpsize += GetEnvironmentVariable( start+1, tmpbuf + strlen(tmpbuf) , size );
					if ( bDebug )
						printf( "From environment: %s = %s\n" , start+1, tmpbuf );
					//If not found in environment fall back to registry
					if ( tmpsize == 0 )
					{
						printf( "Failed to find in environment %s. Looking up registry\n", start+1 );
						tmpsize += GetRegistryValue( "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment", start+1 , tmpbuf + strlen(tmpbuf), size );
					}
				}
				#pragma warning(default:4267)

				size -= tmpsize;
			}
			buf = stop + 1;
			start = strchr( buf,'%');			

		} else
		{
			start = NULL;
		}
	}	

	if ( tmpbuf)
	{
		strcat_s( tmpbuf, bsize, buf );
		strcpy_s( buffer, bsize, tmpbuf );
		free( tmpbuf );
	}

	//printf( "E %s\n", buffer );

	if ( bDebug )
		printf( "Finally:  %s = %s\n" , name, buffer );

	//printf( "End parsing\n" );
	return strlen( buffer );
}

size_t JSLGetProfileString( LPTSTR section, LPTSTR name, LPTSTR _default, LPTSTR buffer, size_t bsize, LPTSTR path )
{
	return JSLGetProfileStringR( section, name, _default, buffer, bsize, path, 0 );
}


VOID runBatch(LPSTR szconfigbatch, LPSTR szconfigbatchhome)
{
	SECURITY_ATTRIBUTES saAttr;
	STARTUPINFO si = { sizeof(STARTUPINFO) };
    PROCESS_INFORMATION pi;
	BOOL bSuccess = FALSE;

	HANDLE g_hChildStd_IN_Rd = NULL;
	HANDLE g_hChildStd_IN_Wr = NULL;
	HANDLE g_hChildStd_OUT_Rd = NULL;
	HANDLE g_hChildStd_OUT_Wr = NULL;

	// Set the bInheritHandle flag so pipe handles are inherited. 
	saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	saAttr.bInheritHandle = TRUE;
	saAttr.lpSecurityDescriptor = NULL;

	// Create a pipe for the child process's STDOUT. 
	if (!CreatePipe(&g_hChildStd_OUT_Rd, &g_hChildStd_OUT_Wr, &saAttr, 0))
	{
		if (bDebug)
			logToFile(GetLastErrorText(szErr, 256));
		exit(-1);
	}
	// Ensure the read handle to the pipe for STDOUT is not inherited.
	if (!SetHandleInformation(g_hChildStd_OUT_Rd, HANDLE_FLAG_INHERIT, 0))
	{
		if (bDebug)
			logToFile(GetLastErrorText(szErr, 256));
		exit(-1);
	}

	// Create a pipe for the child process's STDIN. 
	if (!CreatePipe(&g_hChildStd_IN_Rd, &g_hChildStd_IN_Wr, &saAttr, 0))
	{
		if (bDebug)
			logToFile(GetLastErrorText(szErr, 256));
		exit(-1);
	}

	// Ensure the write handle to the pipe for STDIN is not inherited. 
	if (!SetHandleInformation(g_hChildStd_IN_Wr, HANDLE_FLAG_INHERIT, 0))
	{
		if (bDebug)
			logToFile(GetLastErrorText(szErr, 256));
		exit(-1);
	}


	// Set up members of the STARTUPINFO structure. 
	// This structure specifies the STDIN and STDOUT handles for redirection.
	si.cb = sizeof(STARTUPINFO);
	si.hStdError = g_hChildStd_OUT_Wr;
	si.hStdOutput = g_hChildStd_OUT_Wr;
	si.hStdInput = g_hChildStd_IN_Rd;
	si.dwFlags |= STARTF_USESTDHANDLES;

	//Set command to call
	TCHAR cmdline[512];
	cmdline[0] = 0;
	LPSTR cmd = "cmd.exe /C ";
	strcat_s(cmdline, 512, cmd);
	strcat_s(cmdline, 512, szconfigbatch);
    
	if (bDebug)
		logToFile(cmdline);

	bSuccess = CreateProcess(NULL, cmdline, NULL, NULL, TRUE, CREATE_UNICODE_ENVIRONMENT,
		NULL, szconfigbatchhome, &si, &pi);
    
	// If an error occurs, exit the application. 
	if (!bSuccess)
	{
		if (bDebug)
			logToFile("Error running batch file:");
		if (bDebug)
			logToFile(szconfigbatch);
		if (bDebug)
			logToFile(GetLastErrorText(szErr, 256));

		exit(-1);
	} else
	{
		if (bDebug)
			logToFile("Successfully started batch file:");
		if (bDebug)
			logToFile(szconfigbatch);

		// Successfully created the process.  Wait for it to finish.
		WaitForSingleObject(pi.hProcess, INFINITE);

		// Close handles to the child process and its primary thread.
		// Some applications might keep these handles to monitor the status
		// of the child process, for example. 

		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);

		// Close handles to the stdin and stdout pipes no longer needed by the child process.
		// If they are not explicitly closed, there is no way to recognize that the child process has ended.

		CloseHandle(g_hChildStd_OUT_Wr);
		CloseHandle(g_hChildStd_IN_Rd);

		if (bDebug)
			logToFile("Batch Terminated:");

		DWORD dwRead = -1;
		DWORD size = 0;
		DWORD BUFSIZE = 16 * 1024;
		CHAR chBuf[16*1024];

		for ( ;; )
		{
			bSuccess = ReadFile(g_hChildStd_OUT_Rd, chBuf, BUFSIZE-size, &dwRead, NULL);
			size += dwRead;
			if (!bSuccess || dwRead == 0) break;
		}
		chBuf[size] = 0;

		if (bDebug)
			logToFile("Total bytes read from batch output");
		if (bDebug)
			logToFileD(size);

		if (bDebug)
			logToFile("Environment returned:");
		if (bDebug)
			logToFile(chBuf);

		//Now parse the output and set the new environment
		LPSTR* variables;
		size_t startLine = 0;
	    DWORD VARBUFSIZE = 4 * 1024;
		CHAR varBuf[4 * 1024];
		variables = stringToArray(chBuf, '\r');

		//Search for "ENVIRONMENT" identifying start of environment - otherwise start with line 0
		for (size_t i = 0; variables[i] != NULL; i++)
		{
			
			if (strcmp(variables[i], "ENVIRONMENT") == 0)
			{
				if (bDebug)
					logToFile("Environment delimiter at line:");
				if (bDebug)
					logToFileD(startLine);
				startLine = i + 1;
				break;
			}
		}

		for (size_t i = startLine; variables[i] != NULL; i++)
		{
			LPSTR name = NULL;
			LPSTR value = NULL;

			size_t size = tokenize(variables[i], '=');
			if (size == 2)
			{
				name = next_token(variables[i], name);
				value = next_token(variables[i], name);

				size_t result = GetEnvironmentVariable(name, varBuf, VARBUFSIZE);
				if (result == 0)
				{
					if (bDebug)
						logToFile("Setting new variable:");
					if (bDebug)
						logToFile(name);
					if (bDebug)
						logToFile(value);
					SetEnvironmentVariable(name, value);
				}
				else {
					if (strcmp(varBuf, value) != 0)
					{
						if (bDebug)
							logToFile("Modified variable:");
						if (bDebug)
							logToFile(name);
						if (bDebug)
							logToFile(varBuf);
						if (bDebug)
							logToFile(value);
						SetEnvironmentVariable(name, value);
					}
				}
				
		
			}
		}

		free(variables);

	}




	/*  Using ShellExecute can't obtain output stream nor is environment shared:
	HINSTANCE result;
	result = ShellExecuteA(NULL, "open", szconfigbatch, NULL, szconfigbatchhome, 0 );
	//If Success
	if ((int)result > 32)
	{
		if (bDebug)
			logToFile("Successfully ran batch file:");
		if (bDebug)
			logToFile(szconfigbatch);
	}
	else {
		GetLastErrorText(szErr, 256);
		if (bDebug)
			logToFile("Error running batch file:");
		if (bDebug)
			logToFile(szconfigbatch);
		if (bDebug)
			logToFile((int)result);
		if (bDebug)
			logToFile(szErr);
	}
	*/
}


void getLogFile( LPTSTR szPath )
{
	size_t i;
	char dateTime[32];
	char modulePath[512];

	if (logfile==NULL || strlen(logfile) == 0 )
	{
		if ( GetModuleFileName( NULL, modulePath, 512 ) == 0)
			AddToMessageLog(TEXT("Could not get module name, so in consequence could not locate log file."));	
		strcpy_s( szPath, 512, modulePath );
		i = strlen( szPath )-3;
		szPath[i] = 0;
		if ( strlen(logtimestamp) != 0)
		{
			dateTimeToString ( dateTime, logtimestamp );
			strcat_s( szPath, 512, dateTime );
			strcat_s( szPath, 512, "." );
		}
		strcat_s( szPath, 512, "log" );
	} else {
		strcat_s( szPath, 512, logfile );
		timestampFile( szPath );
	}
}

void timestampFile( LPTSTR szPath )
{
	char dateTime[32];
	char ext[4];
	size_t i;

	if ( strlen(logtimestamp) != 0)
	{
		dateTimeToString ( dateTime, logtimestamp );
		i = strlen( szPath )-3;
		strcpy_s( ext, 4, szPath+i );
		szPath[i] = 0;
		strcat_s( szPath, 512, dateTime );
		strcat_s( szPath, 512, "." );
		strcat_s( szPath, 512, ext );
	}			
}

/**
  * Log to file
*/
void logToFile( LPTSTR s )
{	
	char path[512] = "";
	FILE* f;
	char dateTime[20];
	int fopen_error = 0;

	dateTimeToString (dateTime, "%Y-%m-%d %H:%M:%S");

	printf("%s: %s\n", dateTime, s);
	
	EnterCriticalSection( &csLog );
	getLogFile(path);

	fopen_error = fopen_s( &f, path, "a+" );
	if (fopen_error == 0 && f != NULL) {
		fprintf(f, "%s: %s\n", dateTime, s);
	}
	if (f) fclose( f );
	LeaveCriticalSection( &csLog );
}

void logToFileD(size_t d)
{	
	TCHAR szPath[512]  = "";
	FILE* f;
	char dateTime[20];
	int fopen_error = 0;
	
	dateTimeToString (dateTime, "%Y-%m-%d %H:%M:%S");

	printf("%s: %Id\n", dateTime, d);

	EnterCriticalSection( &csLog );
	getLogFile( szPath );

	fopen_error = fopen_s( &f, szPath, "a+" );
	if (fopen_error == 0) {
		fprintf(f, "%s: %Id\n", dateTime, d);
	}
	if (f)  fclose( f );
	LeaveCriticalSection( &csLog );
}

void logFileExists()
{
	TCHAR szPath[512] = "";
	getLogFile( szPath );
	fileExists( szPath );
}

void fileExists( TCHAR szPath[512] )
{	
	FILE* f;
	errno_t fopen_err;
	char dateTime[20];
	
	dateTimeToString (dateTime, "%Y-%m-%d %H:%M:%S");

	EnterCriticalSection( &csLog );
	fopen_err = fopen_s( &f, szPath, "a+" );	
	//Check if we can log to log file
	if ( fopen_err != 0 )
	{
		printf( "WARNING: Could not open file.\n" );
		printf( "File: %s\n", szPath );
		AddToMessageLog(TEXT("WARNING: Could not open file"));	
		AddToMessageLog( szPath );	
		//exit( fopen_err );
	}
	else {
		if (f) fclose(f);
	}
	LeaveCriticalSection( &csLog );
}




// New 24.06.1999, Heiner Jostkleigrewe
void getIniDir( LPTSTR szPath , LPTSTR szDrive, size_t driveSize, LPTSTR szDir, size_t dirSize)
{
   TCHAR fname[_MAX_FNAME];
   TCHAR ext[_MAX_EXT];
	#ifdef VC6
   _splitpath( szPath, szDrive, szDir, fname, ext );
	#else
   _splitpath_s( szPath, szDrive, driveSize, szDir, dirSize, fname, _MAX_FNAME, ext,_MAX_EXT );
	#endif


}
// New Ende

/**
  * Perform service initialization
 */
void init()
{
	// register a service control handler
    sshStatusHandle = RegisterServiceCtrlHandler( TEXT(SZSERVICENAME), service_ctrl);

}

//
//  FUNCTION: service_main
//
//  PURPOSE: To perform actual initialization of the service
//
//  PARAMETERS:
//    dwArgc   - number of command line arguments
//    lpszArgv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    This routine performs the service initialization and then calls
//    the user defined ServiceStart() routine to perform majority
//    of the work.
//
void WINAPI service_main(DWORD dwArgc, LPTSTR *lpszArgv)
{
	if ( bDebug )
		logToFile( "service main called" );
	
    init();

    if (!sshStatusHandle)
        goto cleanup;

    // Some 
    ssStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
    ssStatus.dwServiceSpecificExitCode = 0;

	if ( bDebug )
		logToFile( "OK 1" );

    // report the status to the service control manager.
    if (!ReportStatusToSCMgr(
		SERVICE_START_PENDING, // service state
        NO_ERROR,              // exit code
        60000))                 // wait hint
        goto cleanup;
	
	
	//p0.99
	//prepare();
    ServiceStart( global_argc, global_argv );

cleanup:

	if ( bDebug )
		logToFile( "Service cleanup" );
	

    // try to report the stopped status to the service control manager.
    if (sshStatusHandle)
        (VOID)ReportStatusToSCMgr(
                            SERVICE_STOPPED,
                            dwErr,
                            0);

	if ( bDebug )
		logToFile( "Service exiting" );
	

    return;
}


//
//  FUNCTION: service_ctrl
//
//  PURPOSE: This function is called by the SCM whenever
//           ControlService() is called on this service.
//
//  PARAMETERS:
//    dwCtrlCode - type of control requested
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
VOID WINAPI service_ctrl(DWORD dwCtrlCode)
{
	if ( bDebug )
		logToFile( "service control call entered" );
    // Handle the requested control code.
    //
    switch(dwCtrlCode)
    {
        // Stop the service.
        //
        // SERVICE_STOP_PENDING should be reported before
        // setting the Stop Event - hServerStopEvent - in
        // ServiceStop().  This avoids a race condition
        // which may result in a 1053 - The Service did not respond...
        // error.
        case SERVICE_CONTROL_STOP:
			if ( bDebug )
				logToFile( "SERVICE_CONTROL_STOP" );
		case SERVICE_CONTROL_SHUTDOWN:
			if ( bDebug )
				logToFile( "SERVICE_CONTROL_SHUTDOWN" );
            ReportStatusToSCMgr(SERVICE_STOP_PENDING, NO_ERROR, 60000);			
            ServiceStop();	
			return;
			
		case SERVICE_CONTROL_PAUSE: 
			if ( bDebug )
				logToFile( "SERVICE_CONTROL_PAUSE" );
			ServicePause();
            return; 

		case SERVICE_CONTROL_CONTINUE: 			 
			if ( bDebug )
				logToFile( "SERVICE_CONTROL_CONTINUE" );
			ReportStatusToSCMgr(SERVICE_CONTINUE_PENDING, NO_ERROR, 60000);
			ServiceContinue();
            return; 

        // Update the service status.
        //
        case SERVICE_CONTROL_INTERROGATE:
			if ( bDebug )
				logToFile( "SERVICE_CONTROL_INTERROGATE" );
            break;

        // invalid control code
        //
        default:
			if ( bDebug )
				logToFile( "Unknown control code" );
            break;

    }

    ReportStatusToSCMgr(ssStatus.dwCurrentState, NO_ERROR, 0);
}



//
//  FUNCTION: ReportStatusToSCMgr()
//
//  PURPOSE: Sets the current status of the service and
//           reports it to the Service Control Manager
//
//  PARAMETERS:
//    dwCurrentState - the state of the service
//    dwWin32ExitCode - error code to report
//    dwWaitHint - worst case estimate to next checkpoint
//
//  RETURN VALUE:
//    TRUE  - success
//    FALSE - failure
//
//  COMMENTS:
//
BOOL ReportStatusToSCMgr(DWORD dwCurrentState,
                         DWORD dwWin32ExitCode,
                         DWORD dwWaitHint)
{
    static DWORD dwCheckPoint = 1;
    BOOL fResult = TRUE;
	returnCode = dwWin32ExitCode;

    if ( !bCommandLine ) // when debugging we don't report to the SCM
    {
        if (dwCurrentState == SERVICE_START_PENDING)
            ssStatus.dwControlsAccepted = 0;
        else
		{
            ssStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
			if ( strlen( pauseClass ) && strlen( pauseMethod ) && strlen( pauseSignature ) && 
				 strlen( contClass ) && strlen( contMethod ) && strlen( contSignature ) )
			{
				ssStatus.dwControlsAccepted |= SERVICE_ACCEPT_PAUSE_CONTINUE;
			}
		}
        ssStatus.dwCurrentState = dwCurrentState;

		//p0.99
		if ( dwCurrentState == SERVICE_STOPPED && dwWin32ExitCode != 0 && strcmp( onExitError, "reportcode" )==0 )
		{
			ssStatus.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
			ssStatus.dwServiceSpecificExitCode = dwWin32ExitCode;
        } else
			ssStatus.dwWin32ExitCode = 0;

		
		if ( dwCurrentState == SERVICE_STOPPED && strcmp( onExitError, "fatal" )==0 && dwWin32ExitCode != 0 )
		{
			//printf( "Fatal exit code %d", dwWin32ExitCode );			
			exit( dwWin32ExitCode );
		}


        ssStatus.dwWaitHint = dwWaitHint;

        if ( ( dwCurrentState == SERVICE_RUNNING ) ||
             ( dwCurrentState == SERVICE_STOPPED ) )
            ssStatus.dwCheckPoint = 0;
        else
            ssStatus.dwCheckPoint = dwCheckPoint++;


        // Report the status of the service to the service control manager.
        //
        if (!(fResult = SetServiceStatus( sshStatusHandle, &ssStatus))) {
            AddToMessageLog(TEXT("SetServiceStatus"));
        }
    }
    return fResult;
}

//
//  FUNCTION: AddToMessageLog(LPTSTR lpszMsg)
//
//  PURPOSE: Allows any thread to log an error message
//
//  PARAMETERS:
//    lpszMsg - text for message
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
VOID AddToMessageLog(LPTSTR lpszMsg)
{
    TCHAR   szMsg[256];
    HANDLE  hEventSource;
    LPTSTR  lpszStrings[2];


    if ( !bDebug )
    {
        dwErr = GetLastError();

        // Use event logging to log the error.
        //
        hEventSource = RegisterEventSource(NULL, TEXT(SZSERVICENAME));

		#ifdef VC6
        _stprintf(szMsg, TEXT("%s error: %d"), TEXT(SZSERVICENAME), dwErr);
		#else
		_stprintf_s(szMsg, 256, TEXT("%s error: %d"), TEXT(SZSERVICENAME), dwErr);
		#endif

        lpszStrings[0] = szMsg;
        lpszStrings[1] = lpszMsg;

        if (hEventSource != NULL) {
            ReportEvent(hEventSource, // handle of event source
                EVENTLOG_ERROR_TYPE,  // event type
                0,                    // event category
                0,                    // event ID
                NULL,                 // current user's SID
                2,                    // strings in lpszStrings
                0,                    // no bytes of raw data
                lpszStrings,          // array of error strings
                NULL);                // no raw data

            (VOID) DeregisterEventSource(hEventSource);
        }
    }
}

size_t GetRegistryValue( LPTSTR keyname, LPTSTR entry, LPTSTR value, size_t valueSize )
{
	HKEY key, subkey;	
	DWORD serviceType = 0x00000010;
	DWORD size;
	DWORD valueType;

	if ( 0 != RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyname, 0, KEY_READ, &subkey ) )
		printf( "Failed to open registry key %s\n", keyname );
	key = subkey;

	//Reading the value
	#pragma warning(disable:4267)
	size = valueSize;
	#pragma warning(default:4267)
	if (0 != RegQueryValueEx(subkey, entry, 0, &valueType, value, &size))
	{
		printf("Failed to read registry entry %s\\%s %s\n", keyname, entry, GetLastErrorText(szErr, 256));
		size = 0;
	}
	RegCloseKey(key);

	valueSize = size;
	return valueSize;
}

void CmdAddServiceParameterRegistry()
{
	HKEY key, subkey;
	LPTSTR keyname = "SYSTEM\\CurrentControlSet\\Services";
	DWORD serviceType = 0x00000010;
	//DWORD size;
	//DWORD valueType;

	if ( 0 != RegOpenKeyEx(HKEY_LOCAL_MACHINE, keyname, 0, KEY_READ, &subkey ) )
		printf( "Failed to open registry key %s\n", keyname );
	key = subkey;

	keyname = szservicename;
	if ( 0 != RegOpenKeyEx(key, keyname, 0, KEY_ALL_ACCESS, &subkey ) )
		printf( "Failed to open registry key %s\n", keyname );

	//Setting the service desscription
	keyname = "Description";
	#pragma warning(disable:4267)
	if ( 0 != RegSetValueEx(subkey, keyname, 0, REG_SZ, szservicedescription, strlen(szservicedescription) ) )
		printf( "Failed to set registry value %s=%s %s\n", keyname,szservicedescription, GetLastErrorText( szErr, 256) );
	#pragma warning(default:4267)
	
	RegCloseKey(subkey);
	RegCloseKey(key);
}


///////////////////////////////////////////////////////////////////
//
//  The following code handles service installation and removal
//
//
//  FUNCTION: CmdConfigureService()
//
//  PURPOSE: Installs the service
//
//  PARAMETERS:
//    none
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//

void CmdConfigureService( int argc, LPTSTR* argv )
{
    SC_HANDLE   schService;
    SC_HANDLE   schSCManager;
	BOOL ret;
	BOOL ret2;
	DWORD serviceType;

	TCHAR szCommand[1024];

	size_t len;

	if (strlen(szModulePath) == 0)
	{
		if (GetModuleFileName(NULL, szModulePath, 1024) == 0)
		{
			_tprintf(TEXT("Unable to configure %s - %s\n"), TEXT(SZSERVICEDISPLAYNAME), GetLastErrorText(szErr, 256));
			returnCode = RET_ERROR;
			return;
		}
	}

	len = strlen(szModulePath) + 2 + 1;
	LPSTR iniFileName = GetArg(argc, argv, "ini", NULL, FALSE);
	if (iniFileName != NULL) {
		if (bDebug)
			printf("Explicitly named ini file\n");
		len += 7;
		len += strlen(iniFileName);
	}

	if (len <= 1024)
	{
		szCommand[0] = 0;
		strcat_s(szCommand, 1024, "\"");
		strcat_s(szCommand, 1024, szModulePath);
		strcat_s(szCommand, 1024, "\"");
		//append -ini <inifile> to modulepath if user specified an ini file on command line
		if (iniFileName != NULL) {
			strcat_s(szCommand, 1024, " -ini \"");
			strcat_s(szCommand, 1024, iniFileName);
			strcat_s(szCommand, 1024, "\"");
		}
	}
	else {
		_tprintf(TEXT("Command path too long."));
		returnCode = RET_ERROR;
		return;
	}
	_tprintf(TEXT("Installing service with command: %s\n"), szCommand);


    schSCManager = OpenSCManager(
                        NULL,                   // machine (NULL == local)
                        NULL,                   // database (NULL == default)
                        SC_MANAGER_ALL_ACCESS   // access required
                        );
    if ( schSCManager )
    {
		schService = OpenService( 
			schSCManager,				// handle to service control manager database 
			TEXT(SZSERVICENAME),		// pointer to name of service to start 
			SERVICE_ALL_ACCESS			// type of access to service
		); 

		if ( schService )
        {
        }
        else
        {
            _tprintf(TEXT("OpenService failed - %s\n"), GetLastErrorText(szErr, 256));
			returnCode = RET_ERROR;
			CloseServiceHandle(schSCManager);
			return;
        }

		serviceType = SERVICE_WIN32_OWN_PROCESS;
		if ( interactwithdesktop == TRUE )
			serviceType |= SERVICE_INTERACTIVE_PROCESS;	

        ret =  ChangeServiceConfig(
            schService,					// SCManager database
            serviceType,  // service type
            dwStartType,				// start type
            SERVICE_ERROR_NORMAL,       // error control type
			szCommand,                  // service start command
            szLoadOrderGroup,           // load ordering group
            NULL,                       // no tag identifier
            szdependencies,				// dependencies
            szAccount,                  // account
            szPwd,						// password
			TEXT(SZSERVICEDISPLAYNAME)
			);   

		//Configure failure actions		
		_tprintf(TEXT("Configuring Failure Actions\n") );
		ret2 = ChangeServiceConfig2( schService, SERVICE_CONFIG_FAILURE_ACTIONS, &failureActions  );

        if ( ret && ret2 )
        {
            _tprintf(TEXT("%s reconfigured.\n"), TEXT(SZSERVICEDISPLAYNAME) );
			returnCode = RET_SUCCESS;
            CloseServiceHandle(schService);
        }
        else
        {
            _tprintf(TEXT("ConfigureService failed - %s\n"), GetLastErrorText(szErr, 256));
			returnCode = RET_ERROR;
        }

        CloseServiceHandle(schSCManager);

		CmdAddServiceParameterRegistry();
    }
    else
	{
        _tprintf(TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
		returnCode = RET_ERROR;
	}
}

//
void CmdInstallService( int argc, LPTSTR* argv )
{
    SC_HANDLE   schService;
    SC_HANDLE   schSCManager;
	BOOL ret2 = TRUE;
	DWORD serviceType;
 
	TCHAR szCommand[1024];
	
	size_t len;

	if ( strlen(szModulePath) == 0 )
	{
		if (GetModuleFileName(NULL, szModulePath, 1024) == 0)
		{
			_tprintf(TEXT("Unable to configure %s - %s\n"), TEXT(SZSERVICEDISPLAYNAME), GetLastErrorText(szErr, 256));
			returnCode = RET_ERROR;
			return;
		}					
	}

	len = strlen(szModulePath) + 2 + 1;
	LPSTR iniFileName = GetArg(argc, argv, "ini", NULL, FALSE);
	if (iniFileName != NULL) {
		if (bDebug)
			printf("Explicitly named ini file\n");
		len += 7;
		len += strlen(iniFileName);
	}

	if ( len <= 1024 )
	{	
		szCommand[0] = 0;
		strcat_s(szCommand, 1024, "\"");
		strcat_s(szCommand, 1024, szModulePath);
		strcat_s(szCommand, 1024, "\"");
		//append -ini <inifile> to modulepath if user specified an ini file on command line
		if (iniFileName != NULL) {
			strcat_s(szCommand, 1024, " -ini \"");
			strcat_s(szCommand, 1024, iniFileName);
			strcat_s(szCommand, 1024, "\"");
		}
	}
	else {
		_tprintf(TEXT("Command path too long."));
		returnCode = RET_ERROR;
		return;
	}

	_tprintf(TEXT("Installing service with command: %s\n"), szCommand);

    schSCManager = OpenSCManager(
                        NULL,                   // machine (NULL == local)
                        NULL,                   // database (NULL == default)
                        SC_MANAGER_ALL_ACCESS   // access required
                        );
    if ( schSCManager )
    {
		serviceType = SERVICE_WIN32_OWN_PROCESS;
		if ( interactwithdesktop == TRUE )
			serviceType |= SERVICE_INTERACTIVE_PROCESS;	

        schService = CreateService(
            schSCManager,               // SCManager database
            TEXT(SZSERVICENAME),        // name of service
            TEXT(SZSERVICEDISPLAYNAME), // name to display
            SERVICE_ALL_ACCESS | GENERIC_EXECUTE | SERVICE_PAUSE_CONTINUE ,         // desired access
            serviceType,  // service type
            dwStartType,				// start type
            SERVICE_ERROR_NORMAL,       // error control type
			szCommand,                   // service start command
            szLoadOrderGroup,			// load ordering group
            NULL,                       // no tag identifier
            szdependencies,				// dependencies
            szAccount,                  // account
            szPwd);                     // password

		//Create failure actions
		if ( schService )
        {
			_tprintf(TEXT("Configuring Failure Actions\n") );
			
			ret2 = ChangeServiceConfig2( schService, SERVICE_CONFIG_FAILURE_ACTIONS, &failureActions  ); //&failureActions
			if ( !ret2 )
			{
				_tprintf(TEXT("ChangeServiceConfig2 error - %s\n"), GetLastErrorText(szErr, 256));
				CloseServiceHandle(schService);
				schService = NULL;
				CmdRemoveService();
			}
			//_tprintf(TEXT("Actions %d\n"), failureActions.cActions );
			//_tprintf(TEXT("Type %d\n"), failureActions.lpsaActions[0].Type );
		}
		

        if ( schService )
        {
            _tprintf(TEXT("%s installed as a Windows service.\n"), TEXT(SZSERVICEDISPLAYNAME) );
            CloseServiceHandle(schService);
			CmdAddServiceParameterRegistry();
			returnCode = RET_SUCCESS;
        }
        else
        {
            _tprintf(TEXT("CreateService failed - %s\n"), GetLastErrorText(szErr, 256));
			_tprintf(TEXT("Account: %s Password: %s\n"), szAccount, szPwd );
			returnCode = RET_ERROR;
        }

        CloseServiceHandle(schSCManager);

    }
    else
	{
        _tprintf(TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
		returnCode = RET_ERROR;
	}
}


//
//  FUNCTION: CmdRemoveService()
//
//  PURPOSE: Stops and removes the service
//
//  PARAMETERS:
//    none
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void CmdRemoveService()
{
    SC_HANDLE   schService;
    SC_HANDLE   schSCManager;

    schSCManager = OpenSCManager(
                        NULL,                   // machine (NULL == local)
                        NULL,                   // database (NULL == default)
                        SC_MANAGER_ALL_ACCESS   // access required
                        );
    _tprintf(TEXT("Removing Service\n") );
	if ( schSCManager )
    {
        schService = OpenService(schSCManager, TEXT(SZSERVICENAME), SERVICE_ALL_ACCESS);

        if (schService)
        {
            // try to stop the service
            if ( ControlService( schService, SERVICE_CONTROL_STOP, &ssStatus ) )
            {
                _tprintf(TEXT("Stopping %s."), TEXT(SZSERVICEDISPLAYNAME));
                Sleep( 1000 );

                while( QueryServiceStatus( schService, &ssStatus ) )
                {
                    if ( ssStatus.dwCurrentState == SERVICE_STOP_PENDING )
                    {
                        _tprintf(TEXT("."));
                        Sleep( 1000 );
                    }
                    else
                        break;
                }

                if ( ssStatus.dwCurrentState == SERVICE_STOPPED )
                    _tprintf(TEXT("\n%s stopped.\n"), TEXT(SZSERVICEDISPLAYNAME) );
                else
                    _tprintf(TEXT("\n%s failed to stop.\n"), TEXT(SZSERVICEDISPLAYNAME) );

            }

            // now remove the service
            if( DeleteService(schService) )
			{
                _tprintf(TEXT("%s removed as a Windows service.\n"), TEXT(SZSERVICEDISPLAYNAME) );
				returnCode = RET_SUCCESS;
			}
            else
			{
                _tprintf(TEXT("DeleteService failed - %s\n"), GetLastErrorText(szErr,256));
				returnCode = RET_ERROR;
			}

            CloseServiceHandle(schService);
        }
        else
		{
            _tprintf(TEXT("OpenService failed - %s\n"), GetLastErrorText(szErr,256));
			returnCode = RET_ERROR;
		}
        CloseServiceHandle(schSCManager);
    }
    else
	{
        _tprintf(TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
		returnCode = RET_ERROR;
	}
}




///////////////////////////////////////////////////////////////////
//
//  The following code is for running the service as a console app
//


//
//  FUNCTION: CmdDebugService(int argc, char ** argv)
//
//  PURPOSE: Runs the service as a console application
//
//  PARAMETERS:
//    argc - number of command line arguments
//    argv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void CmdDebugService(int argc, LPTSTR* argv)
{
    DWORD dwArgc;
    LPTSTR *lpszArgv;

#ifdef UNICODE
    lpszArgv = CommandLineToArgvW(GetCommandLineW(), &(dwArgc) );
#else
    dwArgc   = (DWORD) argc;
    lpszArgv = argv;
#endif

    _tprintf(TEXT("Debugging %s.\n"), TEXT(SZSERVICEDISPLAYNAME));

    SetConsoleCtrlHandler( ControlHandler, TRUE );

	//p0.99
	//prepare();
    ServiceStart( dwArgc, lpszArgv );
}

///////////////////////////////////////////////////////////////////
//
//  The following code is for running the service as a console app
//

//
//  FUNCTION: CmdRunService(int argc, char ** argv)
//
//  PURPOSE: Runs the service as a console application
//
//  PARAMETERS:
//    argc - number of command line arguments
//    argv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//
void CmdRunService(int argc, LPTSTR* argv)
{
    DWORD dwArgc;
    LPTSTR *lpszArgv;

#ifdef UNICODE
    lpszArgv = CommandLineToArgvW(GetCommandLineW(), &(dwArgc) );
#else
    dwArgc   = (DWORD) argc;
    lpszArgv = argv;
#endif

    _tprintf(TEXT("Running %s.\n"), TEXT(SZSERVICEDISPLAYNAME));

    SetConsoleCtrlHandler( ControlHandler, TRUE );

	//p0.99
	//prepare();
    ServiceStart( dwArgc, lpszArgv );
}


//
//  FUNCTION: ControlHandler ( DWORD dwCtrlType )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
BOOL WINAPI ControlHandler ( DWORD dwCtrlType )
{
    switch( dwCtrlType )
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+Break to simulate service pause and continue
			
			if ( bPaused )
			{	
				ServiceContinue();
				bPaused = FALSE;
			} else
			{
				ServicePause();
				bPaused = TRUE;
			}
			
			return TRUE;
			break;

        case CTRL_C_EVENT:   // SERVICE_CONTROL_STOP in debug mode
            _tprintf(TEXT("Stopping %s.\n"), TEXT(SZSERVICEDISPLAYNAME));
            
			ServiceStop();
            return TRUE;
            break;

     
    }
    return FALSE;
}

void redirect_stdxxx()
{	
	char dateTime[20];
	TCHAR szPath[512];

    dateTimeToString (dateTime, "%Y-%m-%d %H:%M:%S");
	//redirect stdout and stderr with check for overwriting

	if ( strlen( stdoutfile ) != 0 )
	{
		strcpy_s( szPath, 512, stdoutfile );
		timestampFile(szPath);
		if (stdOutAppend) {     
			if (freopen_s( &restdout, szPath, "a", stdout ) == 0) {
				fprintf(restdout,"---- Log started: %s\n",dateTime);
				fflush(restdout);
			}
			else if ( bDebug ) {
				char buffer[128]; sprintf_s(buffer, 128, "freopen_s(..., \"a\", stdout) fail [errno=%d]", errno);
				logToFile( buffer );
				logToFile( szPath );
			}    
		} else {
			if (freopen_s( &restdout, szPath, "w", stdout ) == 0) {
				fprintf(restdout,"---- Log started: %s\n",dateTime);
				fflush(restdout);
			}
			else if ( bDebug ) {
				char buffer[128]; sprintf_s(buffer, 128, "freopen_s(..., \"a\", stdout) fail [errno=%d]", errno);
				logToFile( buffer );
				logToFile( szPath );
			}
		}
	}

	if ( strlen( stderrfile ) != 0 ) 
	{
		strcpy_s( szPath, 512, stderrfile );
		timestampFile(szPath);
		if (stdErrAppend) {
			if (freopen_s( &restderr, szPath, "a", stderr ) == 0) {
				fprintf(restderr,"---- Logfile startet: %s\n",dateTime);
				fflush(restderr);
			}
			else if ( bDebug ) {
				char buffer[128]; sprintf_s(buffer, 128, "freopen_s(..., \"a\", stderr) fail [errno=%d]", errno);
				logToFile( buffer );
				logToFile( szPath );
			}
		} else {
			if (freopen_s( &restderr, szPath, "w", stderr ) == 0) {
					fprintf(restderr,"---- Logfile startet: %s\n",dateTime);
					fflush(restderr);
			}
			else if ( bDebug ) {
				char buffer[128]; sprintf_s(buffer, 128, "freopen_s(..., \"a\", stderr) fail [errno=%d]", errno);
				logToFile( buffer );
				logToFile( szPath );
			}	
		}
	}

    if ( bDebug )
        logToFile( "prepare stdxxx - end" );
}


void cleanup()
{
	if ( restdout )
	{
		fclose( restdout );
		restdout = NULL;
	}
	if ( restderr )
	{
		fclose( restderr );
		restderr = NULL;
	}

	if ( bDebug )
		logToFile( "Cleanup complete" );
}

//
//  FUNCTION: GetLastErrorText
//
//  PURPOSE: copies error message text to string
//
//  PARAMETERS:
//    lpszBuf - destination buffer
//    dwSize - size of buffer
//
//  RETURN VALUE:
//    destination buffer
//
//  COMMENTS:
//
LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize )
{
    DWORD dwRet;
    LPTSTR lpszTemp = NULL;
	
	//printf("GetLastErrorText\n");
    dwRet = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
                           NULL,
                           GetLastError(),
                           LANG_NEUTRAL,
                           (LPTSTR)&lpszTemp,
                           0,
                           NULL );

	//printf("(0x%x)", dwRet);
	if (dwRet>0)
	{ 
		if ( dwSize < dwRet + 14)
		{
			lpszTemp[dwSize-14] = TEXT('\0');
		} else {
			lpszTemp[lstrlen(lpszTemp) - 2] = TEXT('\0');  //remove cr and newline character
		}
   
		#ifdef VC6
        _stprintf( lpszBuf, TEXT("%s (0x%x)"), lpszTemp, GetLastError() );
		#else
		printf("Formatting");
		_stprintf_s( lpszBuf, dwSize, TEXT("%s (0x%x)"), lpszTemp, GetLastError() );
		#endif
    }

    if ( lpszTemp )
        LocalFree((HLOCAL) lpszTemp );

    return lpszBuf;
}

#ifdef VC6
void strcat_s( char* dest, size_t sDest, char* src  )
{
	strcat( dest, src);
}

void strcpy_s( char* dest, size_t sDest, char* src  )
{
	strcpy( dest, src);
}

void localtime_s( struct tm* _tm, time_t* timer )
{
	_tm = localtime( timer );
}

size_t fopen_s( FILE** pFile, const char* fname, const char* mode )
{
	*pFile = fopen( fname, mode );
	if ( *pFile != NULL )
		return 0;
	else return 1;
}

size_t freopen_s( FILE** pFile, const char* fname, const char* mode, FILE* stream )
{
	*pFile = freopen( fname, mode, stream );
	if ( *pFile != NULL )
		return 0;
	else return 1;
}

int _snprintf_s( char* dest, size_t sDest, size_t count, char* format, char* p1 )
{
	return _snprintf( dest, count, format, p1 );	
}

#endif


