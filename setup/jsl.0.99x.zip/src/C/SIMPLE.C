/**
  * Java Service Launcher
*/

//#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
//#include <process.h>
//#include <tchar.h>
#include <winsock.h>
#include <process.h>
#include "service.h"
#include "java_start.h"


//
//  FUNCTION: ServiceStart
//
//  PURPOSE: Actual code of the service
//           that does the work.
//
//  PARAMETERS:
//    dwArgc   - number of command line arguments
//    lpszArgv - array of command line arguments
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    The default behavior is to open a
//    named pipe, \\.\pipe\simple, and read
//    from it.  It the modifies the data and
//    writes it back to the pipe.  The service
//    stops when hServerStopEvent is signalled
//
VOID ServiceStart (DWORD dwArgc, LPTSTR *lpszArgv)
{
    //HANDLE                  hEvents[2] = {NULL, NULL};
    //PSECURITY_DESCRIPTOR    pSD = NULL;
	char * arg[] = { "" };

	if ( bDebug )
		logToFile( "service starting" );


    ///////////////////////////////////////////////////
    //
    // Service initialization
    //    
/*
	if (!ReportStatusToSCMgr(
		SERVICE_RUNNING,       // service state
		NO_ERROR,              // exit code
		0))                    // wait hint
		return;
		//goto cleanup;
*/    

	// Let the service control manager know that the service is
    // initializing.
    if (!ReportStatusToSCMgr(
        SERVICE_START_PENDING, 
        NO_ERROR,              
        startdelay + 3000))                 
        //goto cleanup;
        return;


    // Create a Stop Event
    hServerStopEvent = CreateEvent(
        NULL,    
        TRUE,    
        FALSE,   
        NULL);


    if ( hServerStopEvent == NULL)
        goto cleanup;
	
    //
    // End of initialization
    //
    ////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////
    //
    // Service is now running, perform work until shutdown
    //

	if ( bDebug )
		logToFile( "Starting java - Entry" );	
	
	if ( startdelay != 0)
	{
		if (bDebug)
			logToFile("Starting java - Start delay");
		SleepEx( startdelay, FALSE );
	}
	
	if (bDebug)
		logToFile("Starting java");
	java_start ( dwArgc, lpszArgv  );   
	
	if (bDebug)
		logToFile("Starting java - Wait for stop event confirmation from service mananger");
	// Wait for the stop event to be signalled.
	if ( (bCommandLineDebug || bService) )
		WaitForSingleObject(hServerStopEvent,INFINITE);

	if (bDebug)
		logToFile("Starting java - Exiting");
cleanup:

	cleanup();

    if (hServerStopEvent)
        CloseHandle(hServerStopEvent);

}

VOID ServicePause()
{    
	HANDLE ret;
	void** args = malloc( 5 * sizeof(LPTSTR) );

	if ( bDebug )
		logToFile( "pausing service" );
	
	if ( strlen( pauseClass ) && strlen( pauseMethod ) && strlen( pauseSignature ) )
	{
		args[0] = pauseClass;
		args[1] = pauseMethod;
		args[2] = pauseSignature;
		args[3] = pauseParams;	
		args[4] = "SERVICE_PAUSED";			

		printf( "Trying to pause service via JNI call to %s.%s\n", pauseClass, pauseMethod );
		ret = (HANDLE)_beginthread( callJVM, 0, args );
		
		if ( (long)ret == -1 )
			logToFile( "Failed to spawn thread to make JNI call." );
		//else
		//	ReportStatusToSCMgr(SERVICE_PAUSED , 0, 0);
	} 
}

VOID ServiceContinue()
{    
	HANDLE ret;
	void** args = malloc( 5 * sizeof(LPTSTR) );

	if ( bDebug )
		logToFile( "continueing service" );
	
	if ( strlen( contClass ) && strlen( contMethod ) && strlen( contSignature ) )
	{
		args[0] = contClass;
		args[1] = contMethod;
		args[2] = contSignature;
		args[3] = contParams;
		args[4] = "SERVICE_RUNNING";
		
		printf( "Trying to continue service via JNI call to %s.%s\n", contClass, contMethod );
		ret = (HANDLE)_beginthread( callJVM, 0, args );
		
		if ( (long)ret == -1 )
			logToFile( "Failed to spawn thread to make JNI call." );
		//else
		//	ReportStatusToSCMgr(SERVICE_RUNNING , 0, 0);
	} 
}


//
//  FUNCTION: ServiceStop
//
//  PURPOSE: Stops the service
//
//  PARAMETERS:
//    none
//
//  RETURN VALUE:
//    none
//
//  COMMENTS:
//    If a ServiceStop procedure is going to
//    take longer than 3 seconds to execute,
//    it should spawn a thread to execute the
//    stop code, and return.  Otherwise, the
//    ServiceControlManager will believe that
//    the service has stopped responding.
//    
VOID ServiceStop()
{    
	SOCKADDR_IN sin;
	SOCKET _socket;	
	HANDLE ret;
	void** args = malloc( 5 * sizeof(LPTSTR) );
 
	if ( bDebug )
		logToFile( "stopping service" );
		
	
	if ( strlen( stopClass ) && strlen( stopMethod ) && strlen( stopSignature ) )
	{
		args[0] = stopClass;
		args[1] = stopMethod;
		args[2] = stopSignature;
		args[3] = stopParams;
		args[4] = "";

		printf( "Trying to stop service via JNI call to %s.%s\n", stopClass, stopMethod );
		ret = (HANDLE)_beginthread( callJVM, 0, args );

		printf( "Done\n" );
		if ( hServerStopEvent ){
			SetEvent(hServerStopEvent);
		}
		
		if ( (long)ret == -1 )
			logToFile( "Failed to spawn thread to make JNI call." );
		
	} else
	{
		printf( "Trying to stop service via TCP connect to port %d\n", stopport  );
		//Connect to the service on the stop port
		_socket = socket(PF_INET, SOCK_STREAM, 0);
		sin.sin_family = AF_INET;
		sin.sin_addr.s_addr = 0x0100007f;
		sin.sin_port = htons ( (short)stopport );

		if ( connect (_socket, (LPSOCKADDR) &sin, sizeof (sin)) ) {
			fprintf (stderr, "connect failed: %u\n",  WSAGetLastError  ());
			closesocket (_socket);
		} else {
			closesocket (_socket);
			// Signal the stop event.
			if ( hServerStopEvent ){
				SetEvent(hServerStopEvent);
			}
		}

	}
	
}




