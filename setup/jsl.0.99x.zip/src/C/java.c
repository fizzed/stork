/*
 * @(#)java.c	1.54 98/11/19
 *
 * Copyright 1995-1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

/*
 * Shared source for 'java' command line tool.
 *
 * If JAVA_ARGS is defined, then acts as a launcher for applications. For
 * instance, the JDK command line tools such as javac and javadoc (see
 * makefiles for more details) are built with this program.  Any arguments
 * prefixed with '-J' will be passed directly to the 'java' command.
 *
 * If OLDJAVA is defined then enables old-style launcher behavior. In the
 * old launcher, both application and system classes are loaded from the
 * system class path.  In the new launcher, there is a separate class path
 * and class loader for loading application classes.
 */

//#define JAVA_ARGS Hello

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <direct.h>
#include <process.h>

#include <jni.h>
#include "java.h"
#include "service.h"

#ifndef FULL_VERSION
#define FULL_VERSION "1.2"
#endif

static jboolean printVersion = JNI_FALSE;
static char *progname;
jboolean debug = JNI_FALSE;

JavaVM *vm = 0;
//Has been moved to function level to be thread safe. The JNIEnv pointer is only valid in the current thread.
//JNIEnv *env = 0;
BOOL stopCallMade = FALSE;

/*
 * List of VM options to be specified when the VM is created.
 */
static JavaVMOption *options;
static int numOptions, maxOptions;

/*
 * Prototypes for functions internal to launcher.
 */
static void AddOption(char *str, void *info);
static void SetClassPath(char *s);
static jboolean ParseArguments(int *pargc, char ***pargv, char **pjarfile,
			       char **pclassname, int *pret);
static jboolean InitializeJVM(JavaVM **pvm, JNIEnv **penv,
			      InvocationFunctions *ifn);
static void* MemAlloc(size_t size);
static jstring NewPlatformString(JNIEnv *env, char *s);
static jobjectArray NewPlatformStringArray(JNIEnv *env, char **strv, int strc);
static jstring NewPlatformString(JNIEnv *env, char *s);
static jclass LoadClass(JNIEnv *env, char *name);
static jstring GetMainClassName(JNIEnv *env, char *jarname);
BOOL WINAPI ControlHandler2 ( DWORD dwCtrlType );
BOOL redirectStream( JNIEnv* env, char* filename, char* methodname, BOOL append );


#ifdef JAVA_ARGS
static void TranslateDashJArgs(int *pargc, char ***pargv);
static jboolean AddApplicationOptions(void);
#endif

static void PrintJavaVersion(JNIEnv *env, LPSTR version, BOOL print);
static void PrintUsage(void);
static jint PrintXUsage(void);
JNICALL exitHook( jint code );


extern LPTSTR global_wrkdir;

/*
 * Entry point.
 */
int java_start(int argc, char **argv) {
	char *jarfile = 0;
	char *classname = 0;
	char *s = 0;
	jclass mainClass;
	jmethodID mainID;
	jobjectArray mainArgs;
	int ret;
	InvocationFunctions ifn;
	JNIEnv *env = 0;
	char *jvmtype = NULL;
	jboolean jvmspecified = JNI_FALSE;     /* Assume no option specified. */
	jlong start, end;
	//p 0.99
	int errorCode = 0;
	jboolean bConfirmRunning = FALSE;
	char javaversion[128];
	//int javaversionlen;
	jboolean bjreversionallowed = FALSE;

	debug = bDebug;
	if (bDebug)
		logToFile("Java starting 1 - Entry");

	
	//try to change work directory
	if (0 != global_wrkdir){
		if (0 != _chdir(global_wrkdir)){
			AddToMessageLog(TEXT("Unable to change working directory."));
		}
	}

	/* Did the user pass a -classic or -hotspot or server or client as the first option to
	 * the launcher? */
	if (argc > 1) {
		if (strcmp(argv[1], "-hotspot") == 0) {
			jvmtype = "hotspot";
			jvmspecified = JNI_TRUE;
		}
		else if (strcmp(argv[1], "-classic") == 0) {
			jvmtype = "classic";
			jvmspecified = JNI_TRUE;
		}
		else if (strcmp(argv[1], "-server") == 0) {
			jvmtype = "server";
			jvmspecified = JNI_TRUE;
		}
		else if (strcmp(argv[1], "-client") == 0) {
			jvmtype = "client";
			jvmspecified = JNI_TRUE;
		}
	}
	
	ifn.CreateJavaVM = 0; ifn.GetDefaultJavaVMInitArgs = 0;
	if (!LoadJavaVM(jvmtype, &ifn))
		return 1;

	/* Grab the program name */
	progname = *argv++;
	if ((s = strrchr(progname, FILE_SEPARATOR)) != 0) {
		progname = s + 1;
	}
	--argc;

	/* Skip over a specified -classic/-hotspot option */
	if (jvmspecified) {
		argv++;
		argc--;
	}

#ifdef JAVA_ARGS
	/* Preprocess wrapper arguments */
	TranslateDashJArgs(&argc, &argv);
	if (!AddApplicationOptions())
		return 1;
#endif

	if (bDebug)
		logToFile("Java starting 2 - Checking classpath or setting to default classpath.");

	/* Set default CLASSPATH */
	if ((s = getenv("CLASSPATH")) == 0) {
		s = ".";
	}
#ifdef OLDJAVA
	/* Prepend system class path to default */
	{
		JDK1_1InitArgs args;
		char *buf;
		args.version = JNI_VERSION_1_1;
		if (ifn.GetDefaultJavaVMInitArgs(&args) != JNI_OK ||
			args.classpath == 0) {
			fprintf(stderr, "Could not get default system class path.\n");
			return 1;
		}
		buf = MemAlloc(strlen(args.classpath) + strlen(s) + 2);
		sprintf(buf, "%s%c%s", args.classpath, PATH_SEPARATOR, s);
		s = buf;
	}
#endif
#ifndef JAVA_ARGS
	SetClassPath(s);
#endif

	if (bDebug)
		logToFile("Java starting 3 - Logging and parsing command line options.");

	if (bDebug)
	{
		int i;
		for (i = 0; i < argc; i++)
		{
			if (bDebug)
				logToFile(argv[i]);
		}

	}

	/* Parse command line options */
	if (!ParseArguments(&argc, &argv, &jarfile, &classname, &ret)) {
		return ret;
	}

	/* Override class path if -jar flag was specified */
	if (jarfile != 0) {
		SetClassPath(jarfile);
	}

	/* Initialize the virtual machine */

	if (bDebug)
		logToFile("Java starting 3.1 - Start timer call");

	if (debug)
		start = CounterGet();

	if (bDebug)
		logToFile("Java starting 4 - InitializeJVM");


	if (!InitializeJVM(&vm, &env, &ifn)) {
		fprintf(stderr, "Could not create the Java virtual machine.\n");
		logToFile("Could not create the Java virtual machine.");
		return 1;
	}

	if (bDebug)
		logToFile("Java starting 4.1 - PrintJavaVersion if required");

	if (printVersion) {
		PrintJavaVersion(env, javaversion, TRUE);
		if ((*env)->ExceptionOccurred(env)) {
			(*env)->ExceptionDescribe(env);
			ret = 1;
		}
		else {
			ret = 0;
		}
		goto leave;
		
	}
	else {
		PrintJavaVersion(env, javaversion, FALSE);
		if ((*env)->ExceptionOccurred(env)) {
			(*env)->ExceptionDescribe(env);
		}
	}

	if (bDebug)
		logToFile("Java starting 4.2 - Checking against allowed Java versions.");

	bjreversionallowed = CheckJavaVersionAll(javaversion);
	
	if (!bjreversionallowed)
	{
		printf("TERMINATING - Java version not allowed.\n");
		printf("Allowed versions are: " );
		for (int i=0; jreVersions[i] != NULL; i++) printf("'%s' ", jreVersions[i]);
		printf(", but found version '%s'\n", javaversion);
		logToFile("TERMINATING - Java version not allowed.");
		logToFile(javaversion);
		goto leave;
	}

	if ( bDebug )
		logToFile( "Java starting 4.2 - Verifiy start class or jar is specified." );

    /* If the user specified neither a class name or a JAR file */
    if (jarfile == 0 && classname == 0) {
	PrintUsage();
	goto leave;
    }

	if ( bDebug )
		logToFile( "Java starting 4.3 - End Timer and SetConsoleCtrlHandler.");

    if (bDebug) {
		end   = CounterGet();
		printf("%ld micro seconds to InitializeJVM\n",
			   (jint)Counter2Micros(end-start));
    }

	if ( useConsoleHandler || bCommandLineDebug )
		AllocConsole();

	if ( bCommandLineDebug )
	{		
		printf("ControlHandler registered after JVM start\n" );
		SetConsoleCtrlHandler( ControlHandler, TRUE );
	}
	//Handling the shutdown event
	if (useConsoleHandler ) 
	{
		//Override the java Logoff handler if demanded
		SetConsoleCtrlHandler( ControlHandler2, TRUE );
	}

	if ( bDebug )
		logToFile( "Java starting 4.4 - Final application arguments." );

    /* At this stage, argc/argv have the applications' arguments */
    if (bDebug) {
		int i = 0;
		printf("Main-Class is '%s'\n", classname ? classname : "");
		printf("Apps' argc is %d\n", argc);
		for (; i < argc; i++) {
			printf("    argv[%2d] = '%s'\n", i, argv[i]);
		}
    }

    ret = 1;

	if ( bDebug )
		logToFile( "Java starting 5 - Loading main class." );

    /* Get the application's main class */
    if (jarfile != 0) {
	jstring mainClassName = GetMainClassName(env, jarfile);
	if (mainClassName == NULL) {
	    fprintf(stderr, "Failed to load Main-Class manifest attribute "
		    "from\n%s\n", jarfile);
	    goto leave;
	}
	if ((*env)->ExceptionOccurred(env)) {
	    (*env)->ExceptionDescribe(env);
	    goto leave;
	}
	classname = (char *)(*env)->GetStringUTFChars(env, mainClassName, 0);
	if (classname == NULL) {
	    (*env)->ExceptionDescribe(env);
	    goto leave;
	}
	mainClass = LoadClass(env, classname);
	(*env)->ReleaseStringUTFChars(env, mainClassName, classname);
    } else {
	mainClass = LoadClass(env, classname);
    }
    if (mainClass == NULL) {
        (*env)->ExceptionDescribe(env);
		goto leave;
    }

	if ( bDebug )
		logToFile( "Java starting 6 - Java systemout and systemerr redirect. " );

	//Redirect System.out and System.err
	if ( strlen( systemOut ) != 0 )
	{
		if ( !redirectStream( env, systemOut, "setOut", systemOutAppend ) )
			goto leave;
	}

	//Redirect System.out and System.err
	if ( strlen( systemErr ) != 0 )
	{
		if ( !redirectStream( env, systemErr, "setErr", systemErrAppend ) )
			goto leave;
	}

	if (bDebug)
		logToFile("Java starting 6.1 - Find main method in main class. ");

    /* Get the application's main method */
    mainID = (*env)->GetStaticMethodID(env, mainClass, "main",
				       "([Ljava/lang/String;)V");
    if (mainID == NULL) {
	if ((*env)->ExceptionOccurred(env)) {
	    (*env)->ExceptionDescribe(env);
	} else {
	    fprintf(stderr, "No main method found in specified class.\n");
	}
	goto leave;
    }

    /* Build argument array */
    mainArgs = NewPlatformStringArray(env, argv, argc);
    if (mainArgs == NULL) {
	(*env)->ExceptionDescribe(env);
	goto leave;
    }

	if ( bDebug )
		logToFile( "Java starting 7 - Confirm service running and call 'premain' " );
	
	//Check whether we should call the confirm running method. 
	//Once we call it the service will only be set to SERVICE_RUNNING once it returns 
	//As it is started in a seperate thread this will not prevent the main method from being called.
	if ( strlen(confirmrunClass) > 0 && strlen(confirmrunMethod) > 0 && strlen(confirmrunSignature) > 0)
		bConfirmRunning = TRUE;

	if ( bConfirmRunning == FALSE )
	{
		ReportStatusToSCMgr(
			SERVICE_RUNNING,       // service state
			NO_ERROR,              // exit code
			0);                    // wait hint
	}

	if ( bConfirmRunning == TRUE )
	{
		spawnAndWaitForDelayedStatusSetting(confirmrunClass, confirmrunMethod, confirmrunSignature);
	}

	/* Invoke JSLs premain method */
	if ( strlen(premainClass) > 0 && strlen(premainMethod) > 0 && strlen(premainSignature) > 0)
	{
		if ( callPremainMethod( env, premainClass, premainMethod, premainSignature ) != 0 )
		{
			fprintf(stderr, "Could no call premain method or call returned exception.\n");
			goto leave;
		}
	}

	if ( bDebug )
		logToFile( "java starting 7.1 - Invoke main method." );

    /* Invoke main method. */
    (*env)->CallStaticVoidMethod(env, mainClass, mainID, mainArgs);
    
	if ( bDebug )
		logToFile( "Java starting 7.2 - After main method returns." );

	//I don't know why but JVM crashes here on exit if the stopJVM call below has been made
	//Let's just make sure that execption handling is not called in this case
	if ( !stopCallMade && (*env)->ExceptionOccurred(env)) {
		(*env)->ExceptionDescribe(env);
		goto leave;
    }
	

	if ( bDebug )
		logToFile( "Java stopping 8 - Detach thread from JVM" );

    /*
     * Detach the current thread so that it appears to have exited when
     * the application's main method exits.
     */
    if ((*vm)->DetachCurrentThread(vm) != 0) {
		fprintf(stderr, "Could not detach main thread.\n");
		goto leave;
    }
    ret = 0;

	if ( bDebug )
		logToFile( "Java stopping 9 - N/A - obsolete" );

//p0.99
	goto regular;
leave:
	errorCode = exceptionErrorCode;
	breportservicestoppedonmainthreadexit = TRUE;

regular:

	if ( bDebug )
		logToFile( "Java stopping 10 - N/A - obsolete" );

	if (bDebug)
		logToFile("Java stopping 11 - Report Service stopped after main thread exit (optional) ");
	
	if (breportservicestoppedonmainthreadexit)
	{
		ReportStatusToSCMgr(SERVICE_STOPPED, errorCode, 0);

		if (hServerStopEvent)
			SetEvent(hServerStopEvent);
	}


	if ( bDebug )
		logToFile( "java stopping 12 - Destroying JVM" );
	
	if ( bDebug )
		logToFile( "Main Thread has exited. Now making DestroyJavaVM() call. DestroyJavaVM() will block so the JVM will keep running until all daemon threads have terminated." );
	
	printf( "Main Thread has exited. Now making DestroyJavaVM() call. DestroyJavaVM() will block so the JVM will keep running until all daemon threads have terminated.\n" );

	//This waits for all daemon threads to be destroyed.
	//It should usually be safe to use reportservicestoppedonmainthreadexit=true
	//I can't remember why I made this parameter optional. It must have been useful for some people or in some situations
    (*vm)->DestroyJavaVM(vm);
	vm = NULL;	
	
	if ( bDebug )
		logToFile( "Java stopping 13 - Log JVM stopped" );

	printf( "JVM has stopped.\n"  );
	if ( bDebug )
		logToFile( "JVM has stopped" );

	if (bDebug)
		logToFile("Java stopping 14 - Report Service stopped");

	if ( breportservicestoppedonmainthreadexit )
	{		
		

	    ReportStatusToSCMgr(SERVICE_STOPPED, errorCode, 0);		
		
		if ( hServerStopEvent )
			SetEvent(hServerStopEvent);
	}

	if (bDebug)
		logToFile("Java stopping 15 - Done");

    return ret;
}


BOOL redirectStream( JNIEnv* env, char* filename, char* methodname, BOOL append )
{
	//Create a String
	jstring pathString;
	jclass fileOutputStreamClass;
	jmethodID fileOutputStreamConstructor;
	jobject fileOutputStream;
	jclass printStreamClass;
	jmethodID printStreamConstructor;
	jobject printStream;
	jclass systemClass;
	jmethodID setMethod;

	pathString = (*env)->NewStringUTF( env, filename );	
	if (pathString == NULL)
	{
		fprintf(stderr, "Could not create a string for stream redirect.\n");
		goto error;
	}
	//Get FileOutputStream class
    fileOutputStreamClass = (*env)->FindClass(env, "java/io/FileOutputStream");	
	if (fileOutputStreamClass == NULL)
	{
		fprintf(stderr, "Could not find FileOutputStream class.\n");
		goto error;
	}
	
	
	//Get constructor handle
	fileOutputStreamConstructor = (*env)->GetMethodID(env, fileOutputStreamClass, "<init>", "(Ljava/lang/String;Z)V");	
	if (fileOutputStreamConstructor == NULL)
	{
		fprintf(stderr, "Could not find FileOutputStream constructor.\n");
		goto error;
	}
	
	//Create a FileOutputStream instance
	fileOutputStream = (*env)->NewObject(env, fileOutputStreamClass, fileOutputStreamConstructor, pathString, append );
	if (fileOutputStream == NULL)
	{
		fprintf(stderr, "Could not instantiate FileOutputStream.\n");
		goto error;
	}

	//Find the PrintStream class.
    printStreamClass = (*env)->FindClass(env, "java/io/PrintStream");	
    if (printStreamClass == NULL)
	{
		fprintf(stderr, "Could not create PrintStream class.\n");
		goto error;
	}

	//Find the PrintStream constructor.
    printStreamConstructor = (*env)->GetMethodID(env, printStreamClass, "<init>", "(Ljava/io/OutputStream;)V");	
    if (printStreamConstructor == NULL)
	{
		fprintf(stderr, "Could not find PrintStream contructor handle.\n");
		goto error;
	}

	//Create a PrintStream.
    printStream = (*env)->NewObject(env, printStreamClass, printStreamConstructor, fileOutputStream);	
    if (printStream == NULL)
	{
		fprintf(stderr, "Could not instantiate PrintStream.\n");
		goto error;
	}

	//Find the System class.
    systemClass = (*env)->FindClass(env, "java/lang/System");	
    if (systemClass == NULL)
	{
		fprintf(stderr, "Could not find System class.\n");
		goto error;
	}

	//Find the method.
    setMethod = (*env)->GetStaticMethodID(env, systemClass, methodname, "(Ljava/io/PrintStream;)V");	
    if (setMethod == NULL)
	{
		fprintf(stderr, "Could not find %s method handle.\n", methodname);
		goto error;
	}

	//Call the method
	(*env)->CallStaticVoidMethod(env, systemClass, setMethod, printStream);
	if ((*env)->ExceptionOccurred(env)) 
		goto error;
		

	return TRUE;

error:
	if ((*env)->ExceptionOccurred(env)) 
	{
	    (*env)->ExceptionDescribe(env);	
		(*env)->ExceptionClear(env);
	} 
	return FALSE;

}


int callPremainMethod( JNIEnv *env, LPSTR clazz, LPSTR method, LPSTR sig )
{
	jint res;      
	jclass classHandle;
    jmethodID methodID;		

	res = 1;
	classHandle = LoadClass(env, clazz );
	if (classHandle == NULL) {
        (*env)->ExceptionDescribe(env);
		goto error;
	}

	methodID = (*env)->GetStaticMethodID(env, classHandle, method,
				       sig );
    
	if (methodID == NULL) {
	    (*env)->ExceptionDescribe(env);
		goto error;
	}
	

	if ( bDebug )
		logToFile( "About to make JNI call." );

	
	res = (*env)->CallStaticIntMethod(env, classHandle, methodID );
	if ((*env)->ExceptionOccurred(env)) {
		(*env)->ExceptionDescribe(env);
		res = 1;
	}	
	
	if ( bDebug )
		logToFile( "Made JNI call." );

error:
	
	return res;             
}

void spawnAndWaitForDelayedStatusSetting (  LPSTR clazz, LPSTR method, LPSTR sig )
{
	HANDLE ret;
	void** args = malloc( 5 * sizeof(LPTSTR) );
	args[0] = clazz;
	args[1] = method;
	args[2] = sig;
	args[3] = NULL;	
	args[4] = "SERVICE_RUNNING";		
		
	ret = (HANDLE)_beginthread( callJVM, 0, args );
		
	if ( (long)ret == -1 )
		logToFile( "Failed to spawn thread to make JNI call." );	
	else 
	{
		printf( "Spawned delayed status setting call to %s.%s", clazz, method  );	
		logToFile( "Spawned delayed status setting call");	
	}
}

void callJVM( void* arg[])
{
	_callJVMS( arg, 0 );
}

void callJVMStop( void* arg[])
{
	_callJVMS( arg, 1 );
}

void _callJVMS( void* arg[], BOOL stopCall )
{
	//LPSTR *aa = arg;
	LPSTR clazz = arg[0];
	LPSTR method = arg[1];
	LPSTR sig = arg[2];
	LPSTR* args = arg[3];
	LPSTR status = arg[4];
	int size;

	jint res;      
	//Only valid in local thread, therefore we need to decalre it here
	JNIEnv *env;
	jclass classHandle;
    jmethodID methodID;
	
	jstring _string;
	jclass stringClass;
	jmethodID stringConstructor;
	jobjectArray stringArray = NULL;
	jobject argString;

	int i;

	if ( bDebug )
		logToFile( "Call JVM" );

	free(arg);

	//printf( "%s %s %s\n" , clazz, method, sig );

	if ( !vm )
	{
		logToFile( "No jvm handle to make JNI call." );
		return;
	}

	res = (*vm)->AttachCurrentThread(vm, (void**)&env, NULL);	

	classHandle = LoadClass(env, clazz );
	if (classHandle == NULL) {
        (*env)->ExceptionDescribe(env);
		goto error;
	}

	methodID = (*env)->GetStaticMethodID(env, classHandle, method, sig );
	if (methodID == NULL)
	{
		fprintf(stderr, "Could not find method %s with signature %s in class %s.\n", method, sig, clazz);
		goto error;
	}
 
	//If the method signature is String[] and a string array has actually been passed
	if ( args != NULL && strcmp(sig, "([Ljava/lang/String;)V")==0 )
	{
		if ( bDebug )
			logToFile( "Building string array" );

		for( size=0; args[size] != NULL ; size++ );

		stringClass = (*env)->FindClass(env, "java/lang/String");
		if (stringClass == NULL)
		{
			fprintf(stderr, "Could not findclass %s.\n",  clazz);
			goto error;
		}
		stringConstructor = (*env)->GetMethodID(env, stringClass, "<init>", "(Ljava/lang/String;)V");	
		if (stringConstructor == NULL)
		{
			fprintf(stderr, "Could not find method %s with signature %s in class %s.\n", "<init>", "(Ljava/lang/String;)V", "java/lang/String");
			goto error;
		}

		stringArray =(jobjectArray)(*env)->NewObjectArray( env, size, stringClass, 0);
		if (stringArray == NULL)
		{
			fprintf(stderr, "Could not create string array \n");
			goto error;
		}

		if ( bDebug )
			logToFile( "Creating strings" );
		for( i=0; i<size; i++ )
		{
			if ( bDebug )
				logToFile( args[i]  );

			_string = (*env)->NewStringUTF( env, args[i] );	
			argString = (*env)->NewObject(env, stringClass, stringConstructor, _string);
			if (argString == NULL)
			{
				fprintf(stderr, "Could create String\n");
				goto error;
			}
			(*env)->SetObjectArrayElement(env, stringArray,i,argString);
		}
	}
	

	if (methodID == NULL) {
	    (*env)->ExceptionDescribe(env);
		goto error;
	}	
	
	if ( bDebug )
		logToFile( "About to make JNI call." );	

	if (stringArray != NULL )
		(*env)->CallStaticVoidMethod(env, classHandle, methodID, stringArray );
	else if ( strcmp(sig,"(I)V")==0 )
		(*env)->CallStaticVoidMethod(env, classHandle, methodID, 0 );
	else
		(*env)->CallStaticVoidMethod(env, classHandle, methodID );

		
	if ((*env)->ExceptionOccurred(env)) {
		(*env)->ExceptionDescribe(env);
	}	
	
	stopCallMade = stopCall;
	if ( bDebug )
		logToFile( "Made JNI call." );



	if ( status != NULL && strcmp(status, "SERVICE_PAUSED")==0 )
	{
		ReportStatusToSCMgr(SERVICE_PAUSED , 0, 0);	
		if ( bDebug )
		{
			logToFile( "Did set status to:" );
			logToFile( status );
		}
	}
	if ( status != NULL && strcmp(status, "SERVICE_RUNNING")==0 )
	{
		ReportStatusToSCMgr(SERVICE_RUNNING , 0, 0);	
		if ( bDebug )
		{
			logToFile( "Did set status to:" );
			logToFile( status );
		}
	}
			
error:
	
	(*vm)->DetachCurrentThread(vm);                          
}

JNICALL exitHook( jint code )
{
	int _code;	
	_code = code;
	if ( bDebug )
		logToFile( "Exit hook called" );

	printf( "Exit code %d\n", _code );
	
	
	ReportStatusToSCMgr(SERVICE_STOPPED, (DWORD)code, 0);	

	if ( hServerStopEvent ){
		SetEvent(hServerStopEvent);
	}

	if ( bDebug )
		logToFile( "Service stop status set." );

	
	if (bCommandLine)
	{
		cleanup();
		exit(_code);
	}

	_endthread();

	return 0;
}


BOOL WINAPI ControlHandler2 ( DWORD dwCtrlType )
{
    switch( dwCtrlType )
    {
        //  
        case CTRL_LOGOFF_EVENT:
			return TRUE;
            break;   
    }
    return FALSE;
}




/*
 * Adds a new VM option with the given given name and value.
 */
static void
AddOption(char *str, void *info)
{
    /*
     * Expand options array if needed to accomodate at least one more
     * VM option.
     */
    if (numOptions >= maxOptions) {
	if (options == 0) {
	    maxOptions = 4;
	    options = MemAlloc(maxOptions * sizeof(JavaVMOption));
	} else {
	    JavaVMOption *tmp;
	    maxOptions *= 2;
	    tmp = MemAlloc(maxOptions * sizeof(JavaVMOption));
	    memcpy(tmp, options, numOptions * sizeof(JavaVMOption));
	    free(options);
	    options = tmp;
	}
    }
    options[numOptions].optionString = str;
    options[numOptions++].extraInfo = info;
}

static void
SetClassPath(char *s)
{
    char *def = MemAlloc(strlen(s) + 40);
#ifdef OLDJAVA
    sprintf(def, "-Xbootclasspath:%s", s);
#else
    sprintf(def, "-Djava.class.path=%s", s);
#endif
    AddOption(def, NULL);
}

/*
 * Parses command line arguments.
 */
static jboolean
ParseArguments(int *pargc, char ***pargv, char **pjarfile,
		       char **pclassname, int *pret)
{
    int argc = *pargc;
    char **argv = *pargv;
    jboolean jarflag = JNI_FALSE;
    char *arg;

    *pret = 1;
    while ((arg = *argv) != 0 && *arg == '-') {
	argv++; --argc;
	if (strcmp(arg, "-classpath") == 0 || strcmp(arg, "-cp") == 0) {
	    if (argc < 1) {
		fprintf(stderr, "%s requires class path specification\n", arg);
		PrintUsage();
		return JNI_FALSE;
	    }
	    SetClassPath(*argv);
	    argv++; --argc;
#ifndef OLDJAVA
	} else if (strcmp(arg, "-jar") == 0) {
	    jarflag = JNI_TRUE;
#endif
	} else if (strcmp(arg, "-help") == 0 ||
		   strcmp(arg, "-h") == 0 ||
		   strcmp(arg, "-?") == 0) {
	    PrintUsage();
	    *pret = 0;
	    return JNI_FALSE;
	} else if (strcmp(arg, "-version") == 0) {
	    printVersion = JNI_TRUE;
	    return JNI_TRUE;
	} else if (strcmp(arg, "-X") == 0) {
	    *pret = PrintXUsage();
	    return JNI_FALSE;
/*
 * The following case provide backward compatibility with old-style
 * command line options.
 */
	} else if (strcmp(arg, "-verbosegc") == 0) {
	    AddOption("-verbose:gc", NULL);
	} else if (strcmp(arg, "-t") == 0) {
	    AddOption("-Xt", NULL);
	} else if (strcmp(arg, "-tm") == 0) {
	    AddOption("-Xtm", NULL);
	} else if (strcmp(arg, "-debug") == 0) {
	    AddOption("-Xdebug", NULL);
	} else if (strcmp(arg, "-noclassgc") == 0) {
	    AddOption("-Xnoclassgc", NULL);
	} else if (strcmp(arg, "-Xfuture") == 0) {
	    AddOption("-Xverify:all", NULL);
	} else if (strcmp(arg, "-verify") == 0) {
	    AddOption("-Xverify:all", NULL);
	} else if (strcmp(arg, "-verifyremote") == 0) {
	    AddOption("-Xverify:remote", NULL);
	} else if (strcmp(arg, "-noverify") == 0) {
	    AddOption("-Xverify:none", NULL);
	} else if (strncmp(arg, "-prof", 5) == 0) {
	    char *p = arg + 5;
	    char *tmp = MemAlloc( strlen(arg) + 50 );
	    if (*p) {
	        sprintf(tmp, "-Xrunhprof:cpu=old,file=%s", p + 1);
	    } else {
	        sprintf(tmp, "-Xrunhprof:cpu=old,file=java.prof");
	    }
	    AddOption(tmp, NULL);
	} else if (strncmp(arg, "-ss", 3) == 0 ||
		   strncmp(arg, "-oss", 4) == 0 ||
		   strncmp(arg, "-ms", 3) == 0 ||
		   strncmp(arg, "-mx", 3) == 0) {
	    char *tmp = MemAlloc(strlen(arg) + 6);
	    sprintf(tmp, "-X%s", arg + 1); /* skip '-' */
	    AddOption(tmp, NULL);
	} else if (strcmp(arg, "-checksource") == 0 ||
		   strcmp(arg, "-cs") == 0 ||
		   strcmp(arg, "-noasyncgc") == 0) {
	    /* No longer supported */
	    fprintf(stderr,
		    "Warning: %s option is no longer supported.\n",
		    arg);
	} else {
	    AddOption(arg, NULL);
	}
    }

    if (--argc >= 0) {
        if (jarflag) {
	    *pjarfile = *argv++;
	    *pclassname = 0;
	} else {
	    *pjarfile = 0;
	    *pclassname = *argv++;
	}
	*pargc = argc;
	*pargv = argv;
    }

    return JNI_TRUE;
}

/*
 * Initializes the Java Virtual Machine. Also frees options array when
 * finished.
 */
static jboolean
InitializeJVM(JavaVM **pvm, JNIEnv **penv, InvocationFunctions *ifn)
{
    JavaVMInitArgs args;
    jint r;

#ifdef OLDJAVA
    /* Indicate that we are using the old-style launcher */
    AddOption("-Xoldjava", NULL);
#endif

	AddOption( "exit", exitHook );

    memset(&args, 0, sizeof(args));
    args.version  = JNI_VERSION_1_2;
    args.nOptions = numOptions;
    args.options  = options;
    args.ignoreUnrecognized = JNI_FALSE;


    if (debug) {
	int i = 0;
	printf("JavaVM args:\n    ");
	printf("version 0x%08lx, ", args.version);
	printf("ignoreUnrecognized is %s, ",
	       args.ignoreUnrecognized ? "JNI_TRUE" : "JNI_FALSE");
	printf("nOptions is %ld\n", args.nOptions);
	for (i = 0; i < numOptions; i++)
	    printf("    option[%2d] = '%s'\n",
		   i, args.options[i].optionString);
    }

    r = ifn->CreateJavaVM(pvm, (void **)penv, &args);
    free(options);
    return r == JNI_OK;
}


#define NULL_CHECK0(e) if ((e) == 0) return 0
#define NULL_CHECK(e) if ((e) == 0) return

/*
 * Returns a pointer to a block of at least 'size' bytes of memory.
 * Prints error message and exits if the memory could not be allocated.
 */
static void *
MemAlloc(size_t size)
{
    void *p = malloc(size);
    if (p == 0) {
	perror("malloc");
	exit(1);
    }
    return p;
}

/*
 * Returns a new Java string object for the specified platform string.
 */
static jstring
NewPlatformString(JNIEnv *env, char *s)
{
	#pragma warning(disable:4267)
    int len = strlen(s);
	#pragma warning(default:4267)
    jclass cls;
    jmethodID mid;
    jbyteArray ary;

    NULL_CHECK0(cls = (*env)->FindClass(env, "java/lang/String"));
    NULL_CHECK0(mid = (*env)->GetMethodID(env, cls, "<init>", "([B)V"));
    ary = (*env)->NewByteArray(env, len);
    if (ary != 0) {
	jstring str = 0;
	(*env)->SetByteArrayRegion(env, ary, 0, len, (jbyte *)s);
	if (!(*env)->ExceptionOccurred(env)) {
	    str = (*env)->NewObject(env, cls, mid, ary);
	}
	(*env)->DeleteLocalRef(env, ary);
	return str;
    }
    return 0;
}

/*
 * Returns a new array of Java string objects for the specified
 * array of platform strings.
 */
static jobjectArray
NewPlatformStringArray(JNIEnv *env, char **strv, int strc)
{
    jarray cls;
    jarray ary;
    int i;

    NULL_CHECK0(cls = (*env)->FindClass(env, "java/lang/String"));
    NULL_CHECK0(ary = (*env)->NewObjectArray(env, strc, cls, 0));
    for (i = 0; i < strc; i++) {
	jstring str = NewPlatformString(env, *strv++);
	NULL_CHECK0(str);
	(*env)->SetObjectArrayElement(env, ary, i, str);
	(*env)->DeleteLocalRef(env, str);
    }
    return ary;
}

/*
 * Loads a class, convert the '.' to '/'.
 */
static jclass
LoadClass(JNIEnv *env, char *name)
{
    char *buf = MemAlloc(strlen(name) + 1);
    char *s = buf, *t = name, c;
    jclass cls;
    jlong start, end;

    if (debug)
	start = CounterGet();

    do {
        c = *t++;
	*s++ = (c == '.') ? '/' : c;
    } while (c != '\0');
    cls = (*env)->FindClass(env, buf);
    free(buf);

    if (debug) {
		end   = CounterGet();
		printf("%ld micro seconds to load main class\n",
			   (jint)Counter2Micros(end-start));
		printf("----_JAVA_LAUNCHER_DEBUG----\n");
    }

    return cls;
}

/*
 * Returns the main class name for the specified jar file.
 */
static jstring
GetMainClassName(JNIEnv *env, char *jarname)
{
#define MAIN_CLASS "Main-Class"
    jclass cls;
    jmethodID mid;
    jobject jar, man, attr;
    jstring str, result = 0;

    NULL_CHECK0(cls = (*env)->FindClass(env, "java/util/jar/JarFile"));
    NULL_CHECK0(mid = (*env)->GetMethodID(env, cls, "<init>",
					  "(Ljava/lang/String;)V"));
    NULL_CHECK0(str = NewPlatformString(env, jarname));
    NULL_CHECK0(jar = (*env)->NewObject(env, cls, mid, str));
    NULL_CHECK0(mid = (*env)->GetMethodID(env, cls, "getManifest",
					  "()Ljava/util/jar/Manifest;"));
    man = (*env)->CallObjectMethod(env, jar, mid);
    if (man != 0) {
	NULL_CHECK0(mid = (*env)->GetMethodID(env,
				    (*env)->GetObjectClass(env, man),
				    "getMainAttributes",
				    "()Ljava/util/jar/Attributes;"));
	attr = (*env)->CallObjectMethod(env, man, mid);
	if (attr != 0) {
	    NULL_CHECK0(mid = (*env)->GetMethodID(env,
				    (*env)->GetObjectClass(env, attr),
				    "getValue",
				    "(Ljava/lang/String;)Ljava/lang/String;"));
	    NULL_CHECK0(str = NewPlatformString(env, MAIN_CLASS));
	    result = (*env)->CallObjectMethod(env, attr, mid, str);
	}
    }
    return result;
}

#ifdef JAVA_ARGS
char *java_args[]; 
static char *app_classpath[] = APP_CLASSPATH;
static int num_args;
#define NUM_ARGS 0
//#define NUM_ARGS (sizeof(java_args) / sizeof(char *))
#define NUM_APP_CLASSPATH (sizeof(app_classpath) / sizeof(char *))

/*
 * For tools convert 'javac -J-ms32m' to 'java -ms32m ...'
 */
static void
TranslateDashJArgs(int *pargc, char ***pargv)
{
    int argc = *pargc;
    char **argv = *pargv;
    int nargc = argc + NUM_ARGS;
    char **nargv = MemAlloc((nargc + 1) * sizeof(char *));
    int i;

    *pargc = nargc;
    *pargv = nargv;

    /* Copy the VM arguments (i.e. prefixed with -J) */
    for (i = 0; i < NUM_ARGS; i++) {
	char *arg = java_args[i];
	if (arg[0] == '-' && arg[1] == 'J')
	    *nargv++ = arg + 2;
    }

    for (i = 0; i < argc; i++) {
	char *arg = argv[i];
	if (arg[0] == '-' && arg[1] == 'J')
	    *nargv++ = arg + 2;
    }

    /* Copy the rest of the arguments */
    for (i = 0; i < NUM_ARGS; i++) {
	char *arg = java_args[i];
	if (arg[0] != '-' || arg[1] != 'J') {
	    *nargv++ = arg;
	}
    }
    for (i = 0; i < argc; i++) {
	char *arg = argv[i];
	if (arg[0] != '-' || arg[1] != 'J') {
	    *nargv++ = arg;
	}
    }
    *nargv = 0;
}

/*
 * For our tools, we try to add 3 VM options:
 *	-Denv.class.path=<envcp>
 *	-Dapplication.home=<apphome>
 *	-Djava.class.path=<appcp>
 * <envcp>   is the user's setting of CLASSPATH -- for instance the user
 *           tells javac where to find binary classes through this environment
 *           variable.  Notice that users will be able to compile against our
 *           tools classes (sun.tools.javac.Main) only if they explicitly add
 *           tools.jar to CLASSPATH.
 * <apphome> is the directory where the application is installed.
 * <appcp>   is the classpath to where our apps' classfiles are.
 */
static jboolean
AddApplicationOptions()
{
    char *s, *envcp, *appcp, *apphome;
    char home[MAXPATHLEN]; /* application home */
    char separator[] = { PATH_SEPARATOR, '\0' };
    int size, i;

    s = getenv("CLASSPATH");
    if (s) {
	/* 40 for -Denv.class.path= */
	envcp = (char *)MemAlloc(strlen(s) + 40);
	sprintf(envcp, "-Denv.class.path=%s", s);
	AddOption(envcp, NULL);
    }

    if (!GetApplicationHome(home, sizeof(home))) {
	fprintf(stderr, "Can't determine application home\n");
	return JNI_FALSE;
    }

    /* 40 for '-Dapplication.home=' */
    apphome = (char *)MemAlloc(strlen(home) + 40);
    sprintf(apphome, "-Dapplication.home=%s", home);
    AddOption(apphome, NULL);

    /* How big is the application's classpath? */
    size = strlen(home) * NUM_APP_CLASSPATH + 40; /* 40: -Djava.class.path */
    for (i = 0; i < NUM_APP_CLASSPATH; i++) {
	size += strlen(app_classpath[i]);
    }
    appcp = (char *)MemAlloc(size + 1);
    strcpy(appcp, "-Djava.class.path=");
    for (i = 0; i < NUM_APP_CLASSPATH; i++) {
	strcat(appcp, home);			/* c:\program files\myapp */
	strcat(appcp, app_classpath[i]);	/* lib\myapp.jar	  */
	strcat(appcp, separator);		/* ;			  */
    }
    appcp[strlen(appcp)-1] = '\0';  /* remove trailing path seperator */
    AddOption(appcp, NULL);
    return JNI_TRUE;
}
#endif

/*
 * Prints the version information from the java.version and other properties.
 */
static void
PrintJavaVersion(JNIEnv *env, LPSTR javaversion, BOOL print)
{
    jclass sysClass;
    jmethodID getPropID;

    jstring java_version;
    jstring java_vm_name;
    jstring java_vm_info;

    char c_version[128];
    char c_vm_name[256];
    char c_vm_info[256];

    NULL_CHECK(sysClass = (*env)->FindClass(env, "java/lang/System"));
    NULL_CHECK(getPropID = (*env)->GetStaticMethodID(env, sysClass,
						     "getProperty",
			     "(Ljava/lang/String;)Ljava/lang/String;"));

    NULL_CHECK(java_version = (*env)->NewStringUTF(env, "java.version"));
    NULL_CHECK(java_vm_name = (*env)->NewStringUTF(env, "java.vm.name"));
    NULL_CHECK(java_vm_info = (*env)->NewStringUTF(env, "java.vm.info"));

    NULL_CHECK(java_version =
    (*env)->CallStaticObjectMethod(env, sysClass, getPropID, java_version));
    NULL_CHECK(java_vm_name =
    (*env)->CallStaticObjectMethod(env, sysClass, getPropID, java_vm_name));
    NULL_CHECK(java_vm_info =
    (*env)->CallStaticObjectMethod(env, sysClass, getPropID, java_vm_info));

    (*env)->GetStringUTFRegion(env, java_version, 0,
			       (*env)->GetStringLength(env, java_version),
			       c_version);
    (*env)->GetStringUTFRegion(env, java_vm_name, 0,
			       (*env)->GetStringLength(env, java_vm_name),
			       c_vm_name);
    (*env)->GetStringUTFRegion(env, java_vm_info, 0,
			       (*env)->GetStringLength(env, java_vm_info),
			       c_vm_info);
	strcpy_s( javaversion, 128, c_version);

	if (print)
	{
		fprintf(stderr, "java version \"%s\"\n", c_version);
		fprintf(stderr, "%s (%s)\n", c_vm_name, c_vm_info);
	}
}

/*
 * Prints default usage message.
 */
static void
PrintUsage(void)
{
    fprintf(stdout,
	"Usage: %s [-options] class [args...]\n"
#ifndef OLDJAVA
	"           (to execute a class)\n"
	"   or  %s -jar [-options] jarfile [args...]\n"
	"           (to execute a jar file)\n"
#endif
	"\n"
	"where options include:\n"
#ifdef OLDJAVA
	"    -cp -classpath <directories and zip/jar files separated by %c>\n"
	"              set search path for classes and resources\n"
#else
	"    -cp -classpath <directories and zip/jar files separated by %c>\n"
	"              set search path for application classes and resources\n"
#endif
	"    -D<name>=<value>\n"
	"              set a system property\n"
	"    -verbose[:class|gc|jni]\n"
	"              enable verbose output\n"
	"    -version  print product version\n"
	"    -? -help  print this help message\n"
	"    -X        print help on non-standard options\n",
#ifndef OLDJAVA
	progname,
#endif
	progname, PATH_SEPARATOR
    );
}

/*
 * Print usage message for -X options.
 */
static jint
PrintXUsage(void)
{
    char path[MAXPATHLEN];
    char buf[128];
    int n;
    FILE *fp;

    GetXUsagePath(path, sizeof(path));
    fp = fopen(path, "r");
    if (fp == 0) {
        fprintf(stderr, "Can't open %s\n", path);
	return 1;
    }
	#pragma warning(disable:4267)
    while ((n = fread(buf, 1, sizeof(buf), fp)) != 0) {
        fwrite(buf, 1, n, stdout);
    }
	#pragma warning(default:4267)
    fclose(fp);
    return 0;
}
