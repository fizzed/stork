/*
 * @(#)java_md.c	1.9 98/06/29
 *
 * Copyright 1997, 1998 by Sun Microsystems, Inc.,
 * 901 San Antonio Road, Palo Alto, California, 94303, U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of Sun Microsystems, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Sun.
 */

#define _CRT_SECURE_NO_WARNINGS

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <jni.h>
#include "java.h"

#include "service.h"

#ifdef DEBUG
#define JVM_DLL "jvm_g.dll"
#define JAVA_DLL "java_g.dll"
#else
#define JVM_DLL "jvm.dll"
#define JAVA_DLL "java.dll"
#endif
/*
* Helpers to look in the registry for a public JRE.
*/
/*
#define JRE_KEY_ZULU_17 "Software\\Azul Systems\\Zulu\\zulu-17"
#define JRE_KEY_ZULU_16 "Software\\Azul Systems\\Zulu\\zulu-16"
#define JRE_KEY_ZULU_15 "Software\\Azul Systems\\Zulu\\zulu-15"
#define JRE_KEY_ZULU_14 "Software\\Azul Systems\\Zulu\\zulu-14"
#define JRE_KEY_ZULU_13 "Software\\Azul Systems\\Zulu\\zulu-13"
#define JRE_KEY_ZULU_12 "Software\\Azul Systems\\Zulu\\zulu-12"
#define JRE_KEY_ZULU_11 "Software\\Azul Systems\\Zulu\\zulu-11"
#define JRE_KEY_ZULU_10 "Software\\Azul Systems\\Zulu\\zulu-10"
#define JRE_KEY_ZULU_9  "Software\\Azul Systems\\Zulu\\zulu-9"
#define JRE_KEY_ZULU_8  "Software\\Azul Systems\\Zulu\\zulu-8"
*/

#define JRE_KEY_ZULU    "Software\\Azul Systems\\Zulu"
#define JRE_KEY_9	    "Software\\JavaSoft\\JRE"
#define JDK_KEY_9	    "Software\\JavaSoft\\JDK"
#define JRE_KEY_ADOPT	"Software\\AdoptOpenJDK\\JRE"
#define JDK_KEY_ADOPT	"Software\\AdoptOpenJDK\\JDK"
#define JRE_KEY_ADOPTIUM	"Software\\Eclipse Adoptium\\JRE"
#define JDK_KEY_ADOPTIUM	"Software\\Eclipse Adoptium\\JDK"
#define JRE_KEY			"Software\\JavaSoft\\Java Runtime Environment"
#define JDK_KEY			"Software\\JavaSoft\\Java Development Kit"

/*
 * Prototypes.
 */
static jboolean GetPublicJREHomeList(char *buf, jint bufsize, char* reg_key, char* allowedversion);
static jboolean GetPublicJREHomeAOJDKList(char* buf, jint bufsize, char* reg_key, char* allowedversion);
static jboolean GetPublicJREHomeZuluList(char* buf, jint bufsize, char* reg_key, char* allowedversion);

jboolean CheckJavaVersion(char* version, char* allowed);

/*
 * Load JVM of "jvmtype", and intialize the invocation functions.  Notice that
 * if jvmtype is NULL, we try to load hotspot, client or classic VM as the default.  Maybe we
 * need an environment variable that dictates the choice of default VM.
 * As of version 0.99l jvmtype can be a comma seperated list. Effectively making
 * the above hotspot default obsolete as they can now be specified explicitely in order of preference
 */
jboolean
LoadJavaVM(char* jvmtype, InvocationFunctions* ifn)
{
	TCHAR szErr[256];
	char home[MAXPATHLEN], javadll[MAXPATHLEN], jvmdll[MAXPATHLEN];
	HINSTANCE handle;
	struct stat s;
	size_t pathSize = 32767;
	size_t i;
	LPTSTR path;
	LPTSTR* jvmtypes = NULL;

	//Empty string in home
	home[0] = 0;

	/* Is JRE defined in ini file? */
	if (jreSearchPath == TRUE)
	{
		if (bDebug)
			logToFile("Searching for JVM in path from ini file");

		if (strlen(global_jrePath) > 0)
		{
			(void)strcpy(home, global_jrePath);
			sprintf(javadll, "%s\\bin\\" JAVA_DLL, home);
			if (bDebug)
				logToFile(javadll);

			if (stat(javadll, &s) == 0)
			{
				if (bDebug)
					logToFile("Found JVM in path from ini file");
				goto jrefound;
			}
			else {
			}
		}

		if (strlen(global_jrePath) > 0)
		{
			(void)strcpy(home, global_jrePath);
			sprintf(javadll, "%s\\jre\\bin\\" JAVA_DLL, home);
			if (bDebug)
				logToFile(javadll);
			if (stat(javadll, &s) == 0)
			{
				strcat(home, "\\jre");
				if (bDebug)
					logToFile("Found JVM path from ini file");
				goto jrefound;
			}
		}
		//end 01.03.2001 Erwin Vervondel
	}

	if (jreSearchLocal == TRUE)
	{
		/* Is JRE co-located with the application? */
		if (bDebug)
			logToFile("Searching for JVM in ./bin");
		if (GetApplicationHome(home, sizeof(home))) {
			sprintf(javadll, "%s\\bin\\" JAVA_DLL, home);
			if (bDebug)
				logToFile(javadll);
			if (stat(javadll, &s) == 0)
			{
				if (bDebug)
					logToFile("Found JVM in ./bin");
				goto jrefound;
			}
		}
		/* Does this app ship a private JRE in <apphome>\jre directory? */
		if (bDebug)
			logToFile("Searching for JVM in ./jre/bin");
		sprintf(javadll, "%s\\jre\\bin\\" JAVA_DLL, home);
		if (bDebug)
			logToFile(javadll);
		if (stat(javadll, &s) == 0)
		{
			strcat(home, "\\jre");
			if (bDebug)
				logToFile("Found JVM in ./jre/bin");
			goto jrefound;
		}
	}

	registryfindoracle = registryfindoracle || registryfindj9;

	//Now loop through all allowed versions while checkingthe registry 
	for (int i = 0; jreVersions[i] != NULL; i++)
	{

		/* Look for default registry keys JRE 9 or later on this machine. */
		if (jreSearchRegistry == TRUE && registryfindjre == TRUE && registryfindoracle == TRUE)
		{
			if (bDebug)
			{
				logToFile("Searching default JRE 9 or later in registry");
			}

			if (GetPublicJREHomeList(home, sizeof(home), JRE_KEY_9, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		/*Look for default registry keys JDK 9 or later on this machine. */
		if (jreSearchRegistry == TRUE && registryfindjdk == TRUE && registryfindoracle == TRUE)
		{
			if (bDebug)
				logToFile("Searching default JDK 9 or later in registry");

			if (GetPublicJREHomeList(home, sizeof(home), JDK_KEY_9, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		/* Look for default registry keys JRE 8 or older on this machine. */
		if (jreSearchRegistry == TRUE && registryfindjre == TRUE && registryfindoracle == TRUE)
		{
			if (bDebug)
				logToFile("Searching default JRE 8 or older in registry");

			if (GetPublicJREHomeList(home, sizeof(home), JRE_KEY, jreVersions[i]))
			{
				goto jrefound;
			}
		}
		/* Look for default registry keys JDK 8 or older on this machine. */
		if (jreSearchRegistry == TRUE && registryfindjdk == TRUE && registryfindoracle == TRUE)
		{
			if (bDebug)
				logToFile("Searching default JDK 8 or older in registry");

			if (GetPublicJREHomeList(home, sizeof(home), JDK_KEY, jreVersions[i]))
			{
				goto jrefound;
			}
		}



		/* Zulu specific keys */
		if (jreSearchRegistry == TRUE && registryfindazul == TRUE)
		{
			if (bDebug)
				logToFile("Searching ZULU in registry");

			if (GetPublicJREHomeZuluList(home, sizeof(home), JRE_KEY_ZULU, jreVersions[i]))
			{
				goto jrefound;
			}
		}

		/* AdoptOpenJDK specific keys */
		if (jreSearchRegistry == TRUE && registryfindjre && registryfindadoptopenjdk == TRUE)
		{
			if (bDebug)
				logToFile("Searching AdoptOpenJDK JRE or later in registry");

			if (GetPublicJREHomeAOJDKList(home, sizeof(home), JRE_KEY_ADOPT, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		/* Adoptium specific keys */
		if (jreSearchRegistry == TRUE && registryfindjre && registryfindadoptopenjdk == TRUE)
		{
			if (bDebug)
				logToFile("Searching Adoptium JRE or later in registry");

			if (GetPublicJREHomeAOJDKList(home, sizeof(home), JRE_KEY_ADOPTIUM, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		/* AdoptOpenJDK specific keys */
		if (jreSearchRegistry == TRUE && registryfindjdk && registryfindadoptopenjdk == TRUE)
		{
			if (bDebug)
				logToFile("Searching AdoptOpenJDK JDK or later in registry");

			if (GetPublicJREHomeAOJDKList(home, sizeof(home), JDK_KEY_ADOPT, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		/* Adoptium specific keys */
		if (jreSearchRegistry == TRUE && registryfindjdk && registryfindadoptopenjdk == TRUE)
		{
			if (bDebug)
				logToFile("Searching Adoptium JDK or later in registry");

			if (GetPublicJREHomeAOJDKList(home, sizeof(home), JDK_KEY_ADOPTIUM, jreVersions[i]))
			{
				goto jrefound;
			}

		}

		//Custom locations
		for (int i = 0; customregistry[i] != NULL; i++)
		{
			if (bDebug)
			{
				logToFile("Searching in custom registry location:");
				logToFile(customregistry[i]);
			}

			if (GetPublicJREHomeList(home, sizeof(home), customregistry[i], jreVersions[i]))
			{
				goto jrefound;
			}
		}
	}

	//If we did not find a JVM

	logToFile("ERROR: Did no find any JVM in any search locations");
	return JNI_FALSE;


	/* Now we know where JRE is -- the value in the "home" variable. */
jrefound:

	if (bDebug)
		logToFile(javadll);

	//Allow jvmtype to be specified from ini file
	//But first we check of the jvmtype was specified on command line
	if (jvmtype == NULL)
	{
		jvmtype = global_jvmtype;
	}

	if (bDebug)
	{
		logToFile("Allowed JVM types");
		logToFile(jvmtype);
	}
	jvmtypes = stringToArray(jvmtype, ',');

	//Now we run through the list of jvmtypes until we find one that is installed	
	if (jvmtypes != NULL)
	{

		jvmtype = NULL;
		for (i = 0; jvmtype == NULL && jvmtypes[i] != NULL; i++)
		{
			sprintf(jvmdll, "%s\\bin\\%s\\" JVM_DLL, home, jvmtypes[i]);
			if (stat(jvmdll, &s) >= 0)
			{
				jvmtype = jvmtypes[i];
				if (bDebug)
				{
					logToFile("Found allowed JVM type");
					logToFile(jvmdll);
				}
			}
			else {
				sprintf(jvmdll, "%s\\jre\\bin\\%s\\" JVM_DLL, home, jvmtypes[i]);
				if (stat(jvmdll, &s) >= 0)
				{
					jvmtype = jvmtypes[i];
					if (bDebug)
					{
						logToFile("Found allowed JVM type");
						logToFile(jvmdll);
					}
				}
			}
		}
		if (jvmtype == NULL)
		{
			fprintf(stderr, "Error trying to locate any of the JVM types listed below\n");
			for (i = 0; jvmtypes[i] != NULL; i++)
				fprintf(stderr, "Failed to find jvmtype = %s\n", jvmtypes[i]);
			jvmtype = "notinstalledJVMType";
		}
	}


	/* Now we know what the jvmtype should be */
	/*
	sprintf(jvmdll, "%s\\bin\\%s\\" JVM_DLL, home, jvmtype);
	if (bDebug) {
		logToFile( "JVM DLL:" );
		logToFile( jvmdll );
	}
	*/

	//2009.10.24 Fix for msvcrt71.dll dependency. Add JVM home to PATH
	//Should be limited to 32bit

	path = malloc(pathSize);

#pragma warning(disable:4267)
	DWORD size = GetEnvironmentVariable("Path", path, pathSize);
#pragma warning(default:4267)
	if (size != 0 && path != NULL)
	{
		//printf("Path: %s\n", path);
		strcat_s(path, pathSize, ";");
		strcat_s(path, pathSize, home);
		strcat_s(path, pathSize, "\\bin");
		SetEnvironmentVariable("Path", path);

		if (bDebug)
		{
			logToFile("Path Variable:");
			logToFile(path);
		}
	}


    /* Load the Java VM DLL */
    if ((handle = LoadLibrary(jvmdll)) == 0) {
		
		logToFile(GetLastErrorText(szErr, 256));
		logToFile("Error loading JVM");
		logToFile(jvmdll);
		
		fprintf(stderr, "Error loading: %s - Please check the jvmtype parameter in the configuration file.\n", jvmdll);
		if (stat(jvmdll, &s) >= 0)
		{
			fprintf(stderr, "JVM is present but did not load. Please make sure you are using jsl.exe for a 32bit JVM and jsl64.exe for a 64bit JVM.\n");
			#ifdef _WIN64
				logToFile("This is a 64bit jsl64.exe");
				fprintf(stderr, "This is a 64bit jsl64.exe.\n");
			#else
				logToFile("This is a 32bit jsl.exe");
				fprintf(stderr, "This is a 32bit jsl.exe.\n");
			#endif
		}
	return JNI_FALSE;
    }

    /* Now get the function addresses */
    ifn->CreateJavaVM = (void *)GetProcAddress(handle, "JNI_CreateJavaVM");
    ifn->GetDefaultJavaVMInitArgs = (void *)GetProcAddress(handle, "JNI_GetDefaultJavaVMInitArgs");
    if (ifn->CreateJavaVM == 0 || ifn->GetDefaultJavaVMInitArgs == 0) {
		fprintf(stderr, "Can't find JNI interfaces in: %s\n", jvmdll);
		return JNI_FALSE;
    }

    return JNI_TRUE;
}

/*
 * Get the path to the file that has the usage message for -X options.
 */
void
GetXUsagePath(char *buf, jint bufsize)
{
    GetModuleFileName(GetModuleHandle(JVM_DLL), buf, bufsize);
    *(strrchr(buf, '\\')) = '\0';
    strcat(buf, "\\Xusage.txt");
}

/*
 * If app is "c:\foo\bin\javac", then put "c:\foo" into buf.
 */
jboolean
GetApplicationHome(char *buf, jint bufsize)
{
    char *cp;
    GetModuleFileName(0, buf, bufsize);
    *strrchr(buf, '\\') = '\0'; /* remove .exe file name */
    if ((cp = strrchr(buf, '\\')) == 0) {
	/* This happens if the application is in a drive root, and
	 * there is no bin directory. */
	buf[0] = '\0';
	return JNI_FALSE;
    }
    *cp = '\0';  /* remove the bin\ part */
    return JNI_TRUE;
}

#ifdef JAVAW
__declspec(dllimport) char **__initenv;

int WINAPI
WinMain(HINSTANCE inst, HINSTANCE previnst, LPSTR cmdline, int cmdshow)
{
    __initenv = _environ;
    return main(__argc, __argv);
}
#endif



static jboolean
GetStringFromRegistry(HKEY key, const char *name, char *buf, jint bufsize)
{
    DWORD type, size;

    if (RegQueryValueEx(key, name, 0, &type, 0, &size) == 0 && type == REG_SZ && (size < (unsigned int)bufsize)) {
		if (RegQueryValueEx(key, name, 0, 0, buf, &size) == 0) {
			return JNI_TRUE;
		}
    }
    return JNI_FALSE;
}

static jboolean GetPublicJREHomeList(char* home, jint bufsize, char* reg_key, char* versionmatch)
{
	HKEY key = NULL, subkey = NULL, subkey2 = NULL, subkey3 = NULL;
	DWORD idx = 0;
	char version[MAXPATHLEN];
	DWORD versionl = MAXPATHLEN;
	DWORD returnl = MAXPATHLEN;
	jboolean found = FALSE;

	/* Open the JRE registry root*/
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, reg_key, 0, KEY_READ, &key) != 0) {
		if (bDebug)
			fprintf(stderr, "Error opening registry key '%s'\n", reg_key);
		return JNI_FALSE;
	}

	//Try CurrentVersion first
	if (JNI_TRUE != GetStringFromRegistry(key, "CurrentVersion", version, versionl)) {
		fprintf(stderr, "Error reading value of(1):\n\t %s\\CurrentVersion\n", reg_key);
	} else {
		found = CheckJavaVersion(version, versionmatch);
		/* Find installation directory where the current version is installed. */
		if ( found ) {
			if (RegOpenKeyEx(key, version, 0, KEY_READ, &subkey) != ERROR_SUCCESS) {
				fprintf(stderr, "Error opening registry key(2) '%s\\%s'\n", reg_key, version);
				found = JNI_FALSE;
			}
		}
	}

	//Loop through sub keys. THe key is the version
	while (!found && ERROR_SUCCESS == RegEnumKeyEx(key, idx, version, &returnl, NULL, NULL, NULL, NULL))
	{
		if (bDebug) fprintf(stderr, "Opening(1): %s\\%s\n", reg_key, version);
		//Match against allowed versions
		found = CheckJavaVersion(version, versionmatch);
		idx++;
		returnl = versionl;
	}

	if (found) {
		/* Find installation directory where the current version is installed. */
		if (RegOpenKeyEx(key, version, 0, KEY_READ, &subkey) != 0) {
			fprintf(stderr, "Error opening registry key(3) '%s\\%s'\n", reg_key, version);
			RegCloseKey(key);
			return JNI_FALSE;
		}
		if (JNI_TRUE != GetStringFromRegistry(subkey, "JavaHome", home, bufsize)) {
			fprintf(stderr, "Error reading value(4):\n\t %s\\%s\\JavaHome\n", reg_key, version);
			found = JNI_FALSE;
		} 
		RegCloseKey(subkey);
	}
	RegCloseKey(key);
	
	return found;
}

static jboolean GetPublicJREHomeAOJDKList(char* home, jint bufsize, char* reg_key, char* versionmatch)
{
	HKEY key = NULL, subkey = NULL, subkey2 = NULL, subkey3 = NULL;
	DWORD idx = 0;
	char version[MAXPATHLEN];
	DWORD versionl = MAXPATHLEN;
	DWORD returnl = MAXPATHLEN;
	jboolean found = FALSE;

	/* Open the JRE registry root*/
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, reg_key, 0, KEY_READ, &key) != 0) {
		if (bDebug)
			fprintf(stderr, "Error opening registry key '%s'\n", reg_key);
		return JNI_FALSE;
	}

	//Loop through sub keys. The key is the version
	while (!found && ERROR_SUCCESS == RegEnumKeyEx(key, idx, version, &returnl, NULL, NULL, NULL, NULL))
	{
		if (bDebug) fprintf(stderr, "Opening(1): %s\\%s\n", reg_key, version);
		//Match against allowed versions
		found = CheckJavaVersion(version, versionmatch);
		idx++;
	}

	if (found) {
		/* Find installation directory where the current version is installed. */
		if (RegOpenKeyEx(key, version, 0, KEY_READ, &subkey) != 0) {
			fprintf(stderr, "Error opening registry key(3) '%s\\%s'\n", reg_key, version);
			RegCloseKey(key);
			return JNI_FALSE;
		} 
		if (RegOpenKeyEx(subkey, "hotspot", 0, KEY_READ, &subkey2) != 0) {
			fprintf(stderr, "Error opening registry key(3) '%s\\%s'\n", reg_key, version);
			RegCloseKey(key);
			RegCloseKey(subkey);
			return JNI_FALSE;
		}
		if (RegOpenKeyEx(subkey2, "MSI", 0, KEY_READ, &subkey3) != 0) {
			fprintf(stderr, "Error opening registry key(3) '%s\\%s'\n", reg_key, version);
			RegCloseKey(key);
			RegCloseKey(subkey);
			RegCloseKey(subkey2);
			return JNI_FALSE;
		}
		if (JNI_TRUE != GetStringFromRegistry(subkey3, "Path", home, bufsize)) {
			fprintf(stderr, "Error reading value(4):\n\t %s\\%s\\hotspot\\MSI\\Path\n", reg_key, version);
			found = JNI_FALSE;
		}
		RegCloseKey(subkey);
		RegCloseKey(subkey2);
		RegCloseKey(subkey3);
	}
	RegCloseKey(key);

	return found;
}


static jboolean GetPublicJREHomeZuluList(char* home, jint bufsize, char* reg_key, char* allowed)
{
	HKEY key = NULL, subkey = NULL;
	DWORD idx = 0;
	char version[MAXPATHLEN];
	char subfolder[MAXPATHLEN];
	DWORD subfolderl = MAXPATHLEN;
	DWORD returnl = MAXPATHLEN;
	jboolean found = FALSE;

	/* Open the JRE registry root*/
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, reg_key, 0, KEY_READ, &key) != 0) {
		if (bDebug)
			fprintf(stderr, "Error opening registry key(5) '%s'\n", reg_key);
		return JNI_FALSE;
	}

	//Loop through sub keys
	while (!found && ERROR_SUCCESS == RegEnumKeyEx(key, idx, subfolder, &returnl, NULL, NULL, NULL, NULL))
	{
		if (bDebug) fprintf(stderr, "Opening(2): %s\\%s\n", reg_key, subfolder);
		//Open sub key
		if (RegOpenKeyEx(key, subfolder, 0, KEY_READ, &subkey) != ERROR_SUCCESS) {
			fprintf(stderr, "Error opening registry key(6) '%s\\%s'\n", reg_key, subfolder);
			RegCloseKey(key);
			return JNI_FALSE;
		}

		//Get Version in sub key
		if (JNI_TRUE != GetStringFromRegistry(subkey, "CurrentVersion", version, subfolderl)) {
			fprintf(stderr, "Error reading value(7):\n\t %s\\%s\\CurrentVersion\n", reg_key, subfolder);
			RegCloseKey(subkey);
		}
		else {
			//Get path
			if (JNI_TRUE != GetStringFromRegistry(subkey, "InstallationPath", home, bufsize)) {
				fprintf(stderr, "Error reading value(8):\n\t %s\\%s\\InstallationPath\n", reg_key, subfolder);
				RegCloseKey(subkey);
			} else {
				RegCloseKey(subkey);
				//Match against allowed versions
				found = CheckJavaVersion(version, allowed);
			}
		}
		idx++;
		returnl = subfolderl;
	}

	RegCloseKey(key);

	return found;
}

jboolean CheckJavaVersion(char* version, char* allowed)
{
	jboolean bjreversionallowed = FALSE;
	size_t max;

	if (bDebug) {
		logToFile("Checking Java Version:");
		logToFile(version);
		logToFile(allowed);
	}
	max = strlen(allowed);
	if (strncmp(allowed, version, max) == 0) bjreversionallowed = TRUE;
	if (strncmp(allowed, "ANY", strlen(allowed)) == 0) bjreversionallowed = TRUE;

	if (bDebug == TRUE && bjreversionallowed == TRUE) {
		logToFile("Matching:");
		logToFile(allowed);
	}
	return bjreversionallowed;
}


jboolean CheckJavaVersionAll(char* javaversion)
{
	jboolean bjreversionallowed = FALSE;
	size_t max;
	//Check for allowed Java versions
	if (bDebug) {
		logToFile("Checking Java Version:");
		logToFile(javaversion);
	}

	for (int i = 0; bjreversionallowed == FALSE && jreVersions[i] != NULL; i++) {
		max = strlen(jreVersions[i]);
		if (strlen(javaversion) < max) max = strlen(javaversion);
		if (strncmp(jreVersions[i], javaversion, max) == 0) bjreversionallowed = TRUE;
		if (strncmp(jreVersions[i], "ANY", strlen(jreVersions[i])) == 0) bjreversionallowed = TRUE;
		if (bDebug == TRUE && bjreversionallowed == TRUE) {
			logToFile("Matching:");
			logToFile(jreVersions[i]);
		}
	}
	if (!bjreversionallowed)
	{
		logToFile("No matches.");
	}

	return bjreversionallowed;
}



/*
 * Support for doing cheap, accurate interval timing.
 */
static jboolean counterAvailable = JNI_FALSE;
static jboolean counterInitialized = JNI_FALSE;
static LARGE_INTEGER counterFrequency;

jlong CounterGet()
{
    LARGE_INTEGER count;

    if (!counterInitialized) {
	counterAvailable = QueryPerformanceFrequency(&counterFrequency);
	counterInitialized = JNI_TRUE;
    }
    if (!counterAvailable) {
	return 0;
    }
    QueryPerformanceCounter(&count);
    return (jlong)(count.QuadPart);
}

jlong Counter2Micros(jlong counts)
{
    if (!counterAvailable || !counterInitialized) {
	return 0;
    }
    return (counts * 1000 * 1000)/counterFrequency.QuadPart;
}
