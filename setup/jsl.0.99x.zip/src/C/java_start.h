

int java_start(int argc, char **argv);
void callJVM( void* arg );
