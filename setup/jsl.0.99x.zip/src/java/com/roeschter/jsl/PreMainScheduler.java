package com.roeschter.jsl;

import java.util.*;
import java.io.*; 
import java.lang.reflect.*; 
 
/**
  *  
*/ 
public class PreMainScheduler
{                 
    static String modules;
    static int status = 0;
    static Properties props;
      
    static public int run()
    {                               
        System.err.println( "premain: Starting scheduler" );
        loadIniFile();
        System.err.println( "premain: Starting modules" );
        StringTokenizer tokens = new StringTokenizer( modules, "," );
        while( tokens.hasMoreTokens() )
        {
            String token = tokens.nextToken();
            startModule( token );
        }    
        System.err.println( "premain: Done starting modules - returning status code: " + status );
        return status;
    }
    
    static public void startModule( String module)
    {
        String prefix = "premain." + module + "." ;
        System.err.println( "premain: Starting module: " + module );
        try {
            //Object cla = Class.forName( props.getProperty( prefix + "class" ) );
            Class<?> clazz = Class.forName( props.getProperty( prefix + "class" ) ); 
            //Class[] cparams = { Properties.class , String.class };
            Constructor<? > constructor = clazz.getConstructor( Properties.class , String.class );
            Object[] params  = { props, prefix };
            Object obj = constructor.newInstance( params );
            
            Method method = clazz.getMethod( props.getProperty( prefix + "method" ), new Class[0] );
            method.invoke( obj, new Object[0] );
            
        } catch ( Exception e )
        {
            e.printStackTrace();
            if ( isTrue( prefix + "critical" ) )
                throw new RuntimeException( "premain: Exception in critical module: " + module );
            else
                System.err.println( "premain: Failed to start module: " + module );    
        }   
    }
    
    static public boolean isTrue( String name )
    {
        String s = props.getProperty( name );
        if ( s == null )
            s = "false";
        s = s.toUpperCase();
        if (s.equals("TRUE") || s.equals("YES" ) )  
            return true;
        else
            return false;                  
    }   
    
    static public void loadIniFile()     
    {
        String inifile = null;
        try {
            inifile = System.getProperty( "service.inifile" ); 			                      
            props = new WindowsCompatibleProperties();
            props.load( new FileInputStream(inifile) );
            
            modules = props.getProperty( "premain.modules" );        
            if ( modules == null )
                modules = "";
        } catch ( Exception e )
        {
            e.printStackTrace();
            throw new RuntimeException( "premain: Failed to load .ini file: " + inifile );
        }   
    }
    
    
}