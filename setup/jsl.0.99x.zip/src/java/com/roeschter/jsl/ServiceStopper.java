package com.roeschter.jsl;

import java.net.*;    
import java.util.*;
import java.io.*;
                                               
/**
  * Responsible for listening on a port for the service stop signal by the jsl process.
  * Default port is 8375.<BR>
  * If you are running the your application from java command line (not through the jsl.exe)
  * simply use java ServiceStopper.
  * The listener Thread will be started as a daemon Thread.
*/
                                               
public class ServiceStopper extends Thread
{                          
  static ServiceStopper singleton;
  /**
    * Port for stopping the application. Default is 8375
  */
  public static int PORT = 8375;
  
  /**
    * List of Stopable queues the singleton will stop on signal
  */
  protected ArrayList<Stopper> stoppers;
  
  /**
    * The queue that a single stop thread will stop
  */
  protected Stopper stopper;   
  
  private ServiceStopper() 
  { 
  	// Change 24.06.1999 by Heiner Jostkleigrewe
  	// Use a default in getProperty
  	// background: when the application was not started from the "jsl"
  	// there was a number format exception
    String port = System.getProperty( "service.stop.port", Integer.toString(PORT) ); 
    PORT = Integer.parseInt( port );
    stoppers = new ArrayList<Stopper>();
  }
  
  private ServiceStopper( Stopper stopper )
  { 
    this.stopper = stopper;
  }         
   
  private static synchronized ServiceStopper get()
  {
    if ( singleton == null )
    {
      singleton = new ServiceStopper();
      singleton.setDaemon( true );
      singleton.start();
    }                   
    return singleton;
  }
 
 
  /**
    * Stop the stopable on exit. Remark that a Stopable passed here will be stopped asychronously. 
    * In other words, each Stopable will be called in it's own thread concurrently.
  */  
  static public boolean stop( Stopable stopable )
  { 
    return get()._stop( stopable );    
  }     
   
  /**
    * Stop the stopable on exit. 
    * Remark that a Stopable passed here will be stopped synchronized with stopAfter.
    * In other words, you can create a queue of stopables which will be called one after the other
    * all synchronized in the same thread.
  */   
  static public boolean stopAfter( Stopable stopAfter, Stopable stopable )
  { 
    return get()._stopAfter( stopAfter, stopable );    
  }
  
  protected boolean _stop( Stopable stopable )
  { 
    return stopAfter( null, stopable );
  }     
  
  synchronized protected boolean _stopAfter( Stopable stopAfter, Stopable stopable )
  {               
    if ( stopable == null )
      return false;
    //Search for stopAfter
    Stopper after = find( stopAfter );
    
    
    Stopper stopper = new Stopper( stopable );
    if ( after != null )
      after.next = stopper;
    else
    {
      stoppers.add( stopper );
    }                                
    return true;                                    
  }
  
  protected Stopper find( Stopable stopAfter )
  {
    if ( stopAfter == null )
      return null;

    Stopper s;      
    for ( int i=0; i< stoppers.size(); i++ )
    {      
      s = (Stopper)stoppers.get(i);
      while ( s != null )
      {
        if ( s.stopable == stopAfter )
          return s;
        
        s = s.next;
      }
    }
    return null;
  }
   
  class Stopper
  {
    Stopable stopable;      
    Stopper next;
    Stopper( Stopable stopable )
    {
      this.stopable = stopable;
    }
  }
  
  public void run()
  {                              
    //if stoppers is not null this is the singleton, so wait for a stop request
    //else it is a thread spawned to stop a single queue
    if ( stoppers != null )
    { 
      ServerSocket ss = null; 
      try {
        ss = new ServerSocket( PORT );
      //Exit if we cannot connect to the desired port
      } catch (Exception e)
      {             
        e.printStackTrace();
        System.exit(1);
      }       
      //Wait for a socket connection signaling to stop the service
      Socket s = null;  
      System.out.println( "ServiceStopper: Now listening for stop signal on port " + PORT );
      do {                                   
        try {        
          if ( s != null )
            s.close();
          s = ss.accept();
        } catch (Exception e)
        {      
          e.printStackTrace();
        }                         
      //Only allow stop request from the local host  
      } while ( !s.getInetAddress().equals( s.getLocalAddress() ) );
      try {
        ss.close();
        System.out.println( "ServiceStopper: closing socket." );
      } catch (Exception e)
      {      
        e.printStackTrace();
      }  
      
      //Stop all registered Stopables                  
      stopAll();     
    }        
    //Stop a single stopper queue
    else
    {
      stopSingle();
    }
  }
  
  protected void stopAll()
  { 
    Stopper stopper;       
    ArrayList<ServiceStopper> stopThreads = new ArrayList<ServiceStopper>();   
    ServiceStopper s;
    
    //Report our attempt to stop the server
    System.out.println( "ServiceStopper: Got service stop signal" );
              
    //Start stop threads for all stop queues
    for ( int i=0; i< stoppers.size(); i++ )
    {
      System.out.println( "ServiceStopper: Calling stop threads" );
      s = new ServiceStopper( (Stopper)stoppers.get(i) );
      s.start();
      stopThreads.add( s );
    }    
    //Wait for all stop threads to die and exit
    for ( int i=0; i< stopThreads.size(); i++ )
    {
      ServiceStopper thread = (ServiceStopper)stopThreads.get(i);
      try {
        thread.join( thread.timeToWait() );
      } catch ( InterruptedException e )
      {
        e.printStackTrace();
      }                                                                    
    }
	System.out.println( "ServiceStopper: Waiting a moment" );
    //Now the service will stop   
	try {
        sleep( 1000 );
      } catch ( InterruptedException e )
      {
        e.printStackTrace();
      }                   
    System.out.println( "ServiceStopper: Exiting JVM" );
    System.exit( 0 );
  }
                     
  protected int timeToWait()
  {                         
    Stopper s = stopper;
    if ( s != null )
      return s.stopable.timeToWait();
    
    return 1;
  }
                     
  protected void stopSingle()
  {                          
    //Stop all Stopables in the queue
    while( stopper != null )
    {                  
      //System.out.println( "ServiceStopper: stoping" );
      try { 
        stopper.stopable.onServiceStop();
      } catch (Throwable e )
      {
        e.printStackTrace();
      }  
      stopper = stopper.next;
    }     
  }            
   
  /**
    * Stop the service on the default port. 
    * This is useful for debugging purposes when running the java app from command line.
    * A simple java ServiceStopper [port] will stop the application.
  */ 
  public static void main( String[] arg )
  {          
    int port = PORT;                   
    try {                          
      if ( arg.length >= 1 )
        port = Integer.parseInt( arg[0] );
      new Socket( "127.0.0.1", port );
    } catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
            
            
            