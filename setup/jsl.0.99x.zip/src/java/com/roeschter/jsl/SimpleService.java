package com.roeschter.jsl;

import java.net.*;
import java.io.*; 
                  
/**
  * A simple example for a java service.
*/                  
class SimpleService extends Thread implements Stopable
{                                               
                                                                 
  /**                                           
    * Here the telnet server implements the Stopable interface
    * On exit close the server cocket on port 23
  */
  public void onServiceStop()
  {       
    System.out.println( "Stopping Telnet Echo" );           
  }              
                                        
  /**
    * Don't wait if onServiceStop does not return. Terminate immediately.
  */                                        
  public int timeToWait()
  {
    return 0;
  }                                     

  public static void stopit()
  {
  stop = true;
  }

	static boolean stop=false;
                                                                                                                             
  /**                                                         
    * The main method called when the service starts.
  */
  public static void main (String[] argv) throws Exception
  {               	  
	//Create echo server class
    SimpleService echo = new SimpleService();
    //Register it with the ServiceStopper
    ServiceStopper.stop( echo );  

	//Runtime.getRuntime().exec

	while ( !stop )
	{
		Thread.sleep(100 );
	}
	System.out.println( "Exiting" );		                         
	//System.exit(0);
  }
}               

