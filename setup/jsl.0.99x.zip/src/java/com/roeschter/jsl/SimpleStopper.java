package com.roeschter.jsl;

import java.net.*;
import java.io.*; 
 
/**
  * Most simple version of Stopable. Simply call
  * ServiceStopper.stop( new SimpleStopper() );
*/ 
public class SimpleStopper implements Stopable
{                                                  
  public void onServiceStop()
  {                  
  }              
  
  public int timeToWait()
  {
    return 0;
  }                                                                                      
  public static void main( String[] argv )
  {
    ServiceStopper.stop( new SimpleStopper() );
  }

}