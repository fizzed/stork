package com.roeschter.jsl;

import java.net.*;
import java.io.*; 
                  
class StopTest
{                                               
    static boolean exitMain = false;
    static boolean shutDownHook = false;
    
    static boolean exceptionMain = false;
    static boolean exceptionThread = false;
    static boolean startThread = false;
    static boolean callExitMain = false;
    static boolean callExitThread = false;
    
    class Child extends Thread
    {
        
        public void run()
        {
            try {
                Thread.sleep( 5000 );
                                                   
                if ( callExitThread )
                {
                    System.out.println( "Now exiting child thread" );   
                    System.exit(0);  
                }
  
            } catch ( Exception e )
            {
                e.printStackTrace();
            }  
            
            
            if ( exceptionThread )
            {
                System.out.println( "Now creating exception in child thread" );   
                int[] ia = null;
                while ( 1==1 )
                    ia = new int[100000000];
            }   
            
            System.out.println( "Just leaving child thread" );     
               
        }  
    }  
    
    public static void stop()
    {
        System.out.println( "Service stopping" );
        try {
            Thread.sleep( 5000 );
        } catch ( Exception e )
        {
        }    
        System.exit( 0 );
    }   
    
    class ShutDown extends Thread
    {
        public void run()
        {
            System.out.println( "Shutdown hook called");
        }
    }     
                                                                                                                            
    /**                                                         
    * The main method called when the service starts.
    */
    public static void main (String[] argv) throws Exception
    {               	
        System.out.println( "Now starting test" );  
        StopTest st = new StopTest();
        
        for( int i=0; i<argv.length; i++ )
        {
            if ( argv[i].equals( "-exitMain" ) )            
                exitMain = true;   
            if ( argv[i].equals( "-shutDownHook" ) )
                shutDownHook = true;                   
            if ( argv[i].equals( "-exceptionMain" ) )
                exceptionMain = true;     
            if ( argv[i].equals( "-exceptionThread" ) )
                exceptionThread = true;                                       
            if ( argv[i].equals( "-startThread" ) )
                startThread = true;   
            if ( argv[i].equals( "-callExitMain" ) )
                callExitMain = true;   
            if ( argv[i].equals( "-callExitThread" ) )
                callExitThread = true;   
        }
        
                
        if ( shutDownHook )
        {            
            Runtime.getRuntime().addShutdownHook( st.new ShutDown() );
        }
        
        if ( exceptionMain )
        {
            int[] ia = null;
            Thread.sleep(5000);
            while ( 1==1 )
                ia = new int[100000000];
        }    
    
        if ( startThread )
            st.new Child().start();
    
        if ( !exitMain )
        {
            while ( 1==1)
                Thread.sleep(1000);
        }    
    
        System.out.println( "Now exiting main thread" );
    
        if ( callExitMain )
        {            
            System.out.println( "Now calling exit in main" );
            System.exit(0);
        }    
    
    }
}               




