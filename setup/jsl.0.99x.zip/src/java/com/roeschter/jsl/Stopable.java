package com.roeschter.jsl;

/**
  * Implement stop to be informed when the service is about to stop.
  * Multiple instances of Stopable can register themselves with the ServiceStopper.
*/
public interface Stopable
{                  
  /**
    * Called when the service is about to stop.
    * You can't veto against stopping. All you can do is delay it while you are doing cleanup.
    * Some time after the stop call returns, the JVM will stop with System.exit(0).
    * Any exception thrown will be ignored.
  */  
  public void onServiceStop();   
                   
  /**
    * How long should the ServiceStopper wait (in milliseconds) for the stop thread to die?
    * 0 waits for ever. Specify some other value if you want to propose a System.exit() after some timeout.
    * Remark: Is is not guaranteed that the JVM will die after the specefied timeout. 
    * There may be other Stopables being less cooperative.
    * If there are other Stopables in the same queue they may or may not be called after the timeout.
    * They are definetely not called if the call to the previous Stopable does not return.
  */                 
  public int timeToWait();
  
}
