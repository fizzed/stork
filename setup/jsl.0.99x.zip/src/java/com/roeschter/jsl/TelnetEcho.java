package com.roeschter.jsl;

import java.net.*;
import java.io.*; 
import java.util.*; 
                  
/**
  * A simple example for a java service.
  * This is a simple echoing Telnet Server.
  * It accepts telnet connections on port 23 and echos back every character typed.
*/                  
class TelnetEcho extends Thread implements Stopable
{                                               
  /**
    * The server cocket which accepts connections
  */
  ServerSocket ss;
                                                                 
  /**                                           
    * Here the telnet server implements the Stopable interface
    * On exit close the server cocket on port 23
  */
  public void onServiceStop()
  {       
    System.out.println( "Stopping Telnet Echo" );           
    try {
      if ( ss != null )
        ss.close();
    } catch (Exception e) {}
  }              
                                        
  /**
    * Don't wait if onServiceStop does not return. Terminate immediately.
  */                                        
  public int timeToWait()
  {
    return 0;
  }                                     

  /**
    * Open server socket and wait for incoming connections
  */                                                   
  public void run()
  {	
    int ssp = 23;
    //System.out.println( ssp );
    try {
      ss = new ServerSocket( ssp );
    } catch (Exception e)
    {
      e.printStackTrace();
    }

    /**
      * Loop forever waiting for connections
    */
    while ( ss != null  )	
    {    	
      try { 
        new Echo( ss.accept() ).start();      
      } catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }                  
  
  /**
    * The worker thread.
    * Get the socket input stream and echos bytes read
  */    
  class Echo extends Thread
  {              
    Socket s;
    Echo( Socket s )
    {
      this.s = s;
    }
    
    public void run()
    {
      try { 
        InputStream in = s.getInputStream();  
        OutputStream out = s.getOutputStream();  
                        
        while( true )
        {
          int data = in.read();
          if ( data == (int)('?') )
            debugDump( out );
          
          out.write( data );
        }                
      } catch (Exception e)
      { e.printStackTrace();  }
    }
  }  
  
  public void debugDump( OutputStream out )
  {
    write ( out, "Debug dump:\n" );
    wrkDir( out );    
  }
  
  public void wrkDir( OutputStream out )
  {
    File f = new File( "abcd.dat" );
    write( out, f.getAbsolutePath() + "\n" );
    write( out, System.getProperty( "user.dir"  ) + "\n" );
  }
  
  public void write( OutputStream out, String s )
  {
    byte[] bb = s.getBytes();
    try {
      out.write(bb);
    } catch ( IOException e )
    {
      e.printStackTrace();  
    }
  }
     
  public static void paramtest( String[] arg)
  {
    System.out.println( "param passsing test" );
    if ( arg == null )
    {
        System.out.println( arg );
        return;
    }
    for( int i=0; i<arg.length; i++ )
        System.out.println( arg[i] );
  }     
     
     
  public static void pause()
  {
    System.out.println( "Service paused" );
  }    
  
  public static int premain()
  {
    System.out.println( "Premain call" );   
    return 0;
  }    
  
  public static void cont()
  {
    System.out.println( "Service continued" );
  }     
  
  public static void confirmRunning()
  {
    System.out.println( "Service waiting 10 s to confirm running" );
    try {
		  Thread.sleep(10000);
    } catch (Exception e )
    {
      e.printStackTrace();
    }
  }     
                                                                                                                                
  /**                                                         
    * The main method called when the service starts.
  */
  public static void main (String[] argv) throws Exception
  {               	  			                  
    System.out.println( "This is the System.out stream" );
    System.err.println( "This is the System.err stream" );
    			      
    String inifile = System.getProperty( "service.inifile" ); 			      
    System.out.println( "Loading ini file: " + inifile );
    
    Properties props = new WindowsCompatibleProperties();
    props.load( new FileInputStream(inifile) );
    
    System.out.println( props );
    			                         
    //Create echo server class
    TelnetEcho echo = new TelnetEcho();
    //Register it with the ServiceStopper
    //This is a decprecated feature only demontrated for backwards compatibility.
    //Please use the stopmethod,stopclass configuration parameter for stopping a service
    
    //ServiceStopper.stop( echo );         
    
    //Start the echo server thread
    echo.start();
  }
}               




