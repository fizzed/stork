package com.roeschter.jsl;

import java.util.*;
import java.io.*; 
 
/**
  * 
*/ 
public class ThreadDumpListener extends Thread
{       
    String _interface;
    int port;
    String secret;
    
    public ThreadDumpListener( Properties p, String prefix )
    {
        _interface = p.getProperty( prefix + "interface" );
        port = Integer.parseInt( p.getProperty( prefix + "port" ) );
        secret = p.getProperty( prefix + "secret" );
    }    
                    
    public void run()
    {                               
        for ( int i=0; i<65536; i++ )
        {
            int n = Character.getNumericValue((char)i);
            if ( n != -1 )
            {
                System.out.println( Character.UnicodeBlock.of((char)i).toString() + ":" + i + ":" + n );
                
            }
        }    
    }          
    
     
}