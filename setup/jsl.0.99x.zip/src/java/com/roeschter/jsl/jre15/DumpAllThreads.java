package com.roeschter.jsl.jre15;

import java.util.*;
import java.io.*; 
 
/**
  *
*/ 
public class DumpAllThreads
{                   
    public String dump()
    {
        return "nyi";
    }    
    
}